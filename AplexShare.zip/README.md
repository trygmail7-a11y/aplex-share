# Aplex Share

Offline, AirDrop-style file sharing for Android. Kotlin + Jetpack Compose. Phones find each other with
Google's **Nearby Connections** API (Bluetooth + Wi-Fi, no router and no internet needed) and send files
directly to each other. No account, no cloud, no server.

> **Status: Phase 1.** The code has been written but **has not been compiled or run on real phones yet**
> (it was authored in an environment without the Android SDK or devices). Build it, test it on two phones,
> and send back any compile errors or bugs. See "Test checklist" below.

## What works in Phase 1

- Home, Files, Connect, Activity, Profile tabs, light + midnight-blue dark theme, splash screen, app icon
- Nearby discovery with a Nearby sharing switch and visibility: **Everyone** or **Hidden**
- Tap a device -> both phones see a 4-digit code -> Accept / Decline
- QR pairing: "Show my QR" (5-minute, single-use) and "Scan QR" (Google code scanner)
- Send any files: Photos, Videos, Music, installed Apps (base APK), anything via the system picker, whole folders
- Multi-select, Select all, search, sort by name/size/date, thumbnails, preview
- Receiver must accept every transfer; several incoming requests queue up
- Real progress, speed and time left from the transfer layer; Cancel; Retry (re-sends)
- SHA-256 check of every file; transfer only counts as done after the receiver verified all files
- Received files go to `Downloads/Aplex Share` (folder structure kept); Open, Share, View folder
- Transfer history (All / Sent / Received / Failed), details, clear history
- Foreground service + notifications while transferring
- Files shared from other apps (Share -> Aplex Share) land in the selection
- Custom device name and avatar

## Phase 1.1 changes

- **Speed:** connection mode changed to point-to-point so Nearby can upgrade to Wi-Fi Direct/hotspot. SHA-256 is now computed while the file is already sending (no waiting before each file). 6 files in flight at once.
- **Setup check:** Connect tab shows Bluetooth / Wi-Fi / Location status and opens Android's own prompts one by one. Android does not allow apps to switch them on silently. Wi-Fi on = fast transfer; Wi-Fi off = slow Bluetooth fallback.
- **Quick Share switch** on Home (on by default). While on, a small foreground service keeps the phone discoverable and searching, also after the app is closed and after reboot.
- **Nearby notification:** when a phone with Aplex Share is close, a heads-up notification appears with *Send files* and *Connect*. Connection requests and incoming files get *Accept / Decline* buttons right in the notification.
- Location permission is now requested on every Android version (needed for Bluetooth scan results).
- New Home hero card, gradient buttons, redesigned bottom bar.

## Phase 1.3: touch to connect (AirDrop style)

Hold two phones top-to-top (a few cm apart). Both phones show **"Connect to X? [Connect] [Not now]"** on their own, even if Aplex Share is closed and nobody pressed anything. How it works: each phone sends a tiny Bluetooth LE beacon and listens for beacons; a very strong signal for about a second means "touching". Distance from signal strength is only an estimate, so Profile -> **Touch distance** (Very close / Close / Near) lets you tune it. It runs only while the screen is on. Needs Quick Share on, Bluetooth on, and the overlay permission for pop-ups while the app is closed.

## Phase 1.2: pop-ups when the app is closed

Needs the **Display over other apps** permission (Home shows an Allow card). Without it, the app falls back to notifications.

1. A phone with Aplex Share comes close -> pop-up "X is nearby" [Connect]
2. Other phone -> pop-up "X wants to connect, code 1234" [Accept] [Decline]
3. Both phones -> pop-up "Connected to X" [Send files] [Receive files]
4. Send files -> system file picker opens, chosen files are sent. Receive files -> Aplex Share opens on the Receive screen.
5. Incoming files -> pop-up [Accept] [Decline]

On Xiaomi / Redmi / Samsung / Oppo etc. also set the app to **Autostart on** and **Battery: No restrictions**, otherwise the phone may stop the background service.

## Known limits (honest list)

- `SYSTEM_ALERT_WINDOW` is a sensitive permission on Google Play; you will need to justify it in the Play Console.

- Quick Share runs continuously, so it uses some battery. Turn the switch off to stop it.
- Connections still need the other phone's approval (one tap, in the app or in the notification). This is deliberate for security.
- Point-to-point mode connects to one phone at a time.

- **Pause/Resume**: Nearby Connections cannot pause a payload, so there is no Pause button. Cancel and Retry exist. Retry sends the file again from the start.
- **Contacts Only** visibility is not included (it cannot be done properly without accounts).
- Apps are sent as the base APK; apps installed as split bundles may not install on the receiver.
- Documents, ZIPs and other non-media files come from the system picker, not an in-app storage browser. This is deliberate: the all-files permission is restricted on Google Play.
- Needs Android 10+ (minSdk 29) and Google Play services on both phones.
- QR scanner uses a Google Play services module that may download once the first time.
- Discovery only runs while the app is open (battery). Keep the app open on the receiving phone.

## Phase 2 (not built yet)

Group rooms (one sender to many), text/link/clipboard sharing, contact export, phone migration assistant,
password-protected sessions, favorites/recents, duplicate warnings, more languages, pause/resume.

## Build

### Android Studio
1. Install Android Studio (Ladybug or newer) with JDK 17.
2. File -> Open -> select this folder. Let Gradle sync.
3. Run on a device, or Build -> Build APK(s).

### GitHub Actions (no Android Studio needed)
1. Create a new GitHub repository and upload **the contents** of this folder (not the folder itself).
2. Open the **Actions** tab -> **Build APK** -> **Run workflow** (it also runs on every push).
3. When it finishes, open the run and download **AplexShare-debug-apk** from Artifacts. Unzip and install the APK.

### Signed release APK / Play Store
1. Create a keystore on your computer: `keytool -genkey -v -keystore release.jks -keyalg RSA -keysize 2048 -validity 10000 -alias aplex`
2. Base64 it: `base64 -w0 release.jks` (macOS: `base64 -i release.jks`)
3. In GitHub: Settings -> Secrets and variables -> Actions, add `KEYSTORE_BASE64`, `KEYSTORE_PASSWORD`, `KEY_ALIAS`, `KEY_PASSWORD`.
4. Re-run the workflow. It now also uploads **AplexShare-release-apk**.
5. For Play Store you need an `.aab`: run `gradle :app:bundleRelease` locally with the same env vars.

Never commit the keystore or passwords. `.gitignore` already blocks `*.jks`.

## Test checklist (two real Android phones)

1. Install on both. Allow Nearby / Bluetooth / notification permissions.
2. Turn **off** mobile data and Wi-Fi internet (Bluetooth + Wi-Fi radios stay on). Open the app on both.
3. Phone B: Home -> Receive. Phone A: Files -> pick photos -> Send -> tap B. Compare the 4-digit code, accept on both.
4. B sees the incoming list -> Accept. Watch progress, speed, success screen. Check `Downloads/Aplex Share`.
5. Repeat with a video > 1 GB, a ZIP (Documents & more), a folder, and an app.
6. Try QR: B -> Show my QR, A -> Scan QR.
7. Cancel mid-transfer, walk out of range, then Retry.
8. Check Activity tabs and Clear history.

## Privacy & security

- No account, no analytics, no ads, no server. Aplex Share requests no INTERNET permission of its own.
- Nearby Connections encrypts the link. The 4-digit code protects against pairing with the wrong phone.
- QR pairing: public session id in the advertisement, secret only in the QR, proved over the encrypted channel, single use, 5-minute expiry.
- Incoming file names are sanitized (no `..`, no absolute paths). Files are only saved after you tap Accept.
- Received APKs are never installed automatically.

## Project layout

```
app/src/main/java/com/aplex/share/
  core/   NearbyEngine (discovery, pairing, protocol, transfer), Storage, MediaRepo, QR, notifications, service
  data/   models, prefs, history, selection
  ui/     Compose screens
.github/workflows/build-apk.yml
```
