package com.aplex.share.ui

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import com.aplex.share.core.*
import com.aplex.share.data.*
import kotlinx.coroutines.delay

private val NAV: List<Pair<String, ImageVector>> = listOf(
    "Home" to Icons.Rounded.Home,
    "Files" to Icons.Rounded.Folder,
    "Connect" to Icons.Rounded.Wifi,
    "Activity" to Icons.Rounded.History,
    "Profile" to Icons.Rounded.Person
)

@Composable
fun AppRoot() {
    val ctx = LocalContext.current
    val dark = when (Prefs.theme) { 1 -> false; 2 -> true; else -> isSystemInDarkTheme() }

    AplexTheme(dark) {
        var tab by rememberSaveable { mutableIntStateOf(0) }
        var catOrdinal by rememberSaveable { mutableIntStateOf(Category.PHOTO.ordinal) }
        var overlay by remember { mutableStateOf<Overlay?>(null) }
        val snack = remember { SnackbarHostState() }
        val cat = Category.values()[catOrdinal]

        // ---- permission helper shared with every screen ----
        var pendingAction by remember { mutableStateOf<(() -> Unit)?>(null) }
        var pendingPerms by remember { mutableStateOf<List<String>>(emptyList()) }
        val permLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
            NearbyEngine.refreshPerms(ctx)
            NearbyEngine.onAppVisible(true)
            if (Permissions.has(ctx, pendingPerms.toTypedArray())) pendingAction?.invoke()
            else NearbyEngine.message = "Permission needed. You can allow it in the app's settings."
            pendingAction = null
        }
        val ensure: (Array<String>, () -> Unit) -> Unit = remember {
            { perms, action ->
                val missing = perms.filter { ContextCompat.checkSelfPermission(ctx, it) != PackageManager.PERMISSION_GRANTED }
                if (missing.isEmpty()) action()
                else {
                    pendingPerms = perms.toList()
                    pendingAction = action
                    permLauncher.launch(missing.toTypedArray())
                }
            }
        }
        val notifLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { }
        LaunchedEffect(Unit) {
            if (Build.VERSION.SDK_INT >= 33 &&
                ContextCompat.checkSelfPermission(ctx, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
            ) notifLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
        }

        // ---- engine -> UI signals ----
        val msg = NearbyEngine.message
        LaunchedEffect(msg) {
            if (msg != null) { snack.showSnackbar(msg); NearbyEngine.message = null }
        }
        LaunchedEffect(NearbyEngine.focusTransferId) {
            NearbyEngine.focusTransferId?.let { overlay = Overlay.Progress(it); NearbyEngine.focusTransferId = null }
        }
        LaunchedEffect(NearbyEngine.lastCompleted) {
            NearbyEngine.lastCompleted?.let { overlay = Overlay.Success(it.id); NearbyEngine.lastCompleted = null }
        }
        LaunchedEffect(NearbyEngine.pairedName) {
            if (NearbyEngine.pairedName != null) {
                if (overlay is Overlay.MyQr) overlay = null
                delay(1800)
                NearbyEngine.pairedName = null
            }
        }
        LaunchedEffect(UiBus.goSelected) {
            if (UiBus.goSelected) { tab = 1; catOrdinal = Category.OTHER.ordinal; UiBus.goSelected = false }
        }
        LaunchedEffect(tab, overlay) {
            NearbyEngine.setDiscoveryWanted(overlay == null && (tab == 0 || tab == 2))
            NearbyEngine.setReceiveMode(overlay is Overlay.Receive)
        }

        BackHandler(enabled = overlay != null) { overlay = null }
        BackHandler(enabled = overlay == null && tab != 0) { tab = 0 }

        CompositionLocalProvider(LocalEnsure provides ensure) {
            Box(Modifier.fillMaxSize()) {
                Scaffold(
                    containerColor = MaterialTheme.colorScheme.background,
                                        bottomBar = { if (overlay == null) BottomBar(tab) { tab = it } }
                ) { pad ->
                    Box(Modifier.padding(pad).fillMaxSize()) {
                        when (tab) {
                            0 -> HomeScreen(
                                goTab = { tab = it }, open = { overlay = it },
                                openCat = { c -> catOrdinal = c.ordinal; tab = 1 }
                            )
                            1 -> FilesScreen(cat, onCat = { catOrdinal = it.ordinal }, goConnect = { tab = 2 })
                            2 -> ConnectScreen(open = { overlay = it }, goFiles = { tab = 1 })
                            3 -> ActivityScreen(open = { overlay = it })
                            else -> ProfileScreen()
                        }
                    }
                }

                overlay?.let { o ->
                    Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
                        Box(Modifier.fillMaxSize().systemBarsPadding()) {
                            when (o) {
                                Overlay.Receive -> ReceiveScreen(
                                    onClose = { overlay = null },
                                    onQr = { overlay = Overlay.MyQr },
                                    onScan = { ensure(Permissions.nearby()) { QrScan.start(ctx) } }
                                )
                                Overlay.MyQr -> MyQrScreen { overlay = null }
                                is Overlay.Progress -> ProgressScreen(o.id) { overlay = null }
                                is Overlay.Success -> SuccessScreen(o.id, onDone = { overlay = null }, onViewFiles = { overlay = null; tab = 3 })
                            }
                        }
                    }
                }

                NearbyEngine.pairedName?.let { PairedBanner(it) }
                SnackbarHost(snack, Modifier.align(Alignment.BottomCenter).navigationBarsPadding().padding(bottom = if (overlay == null) 76.dp else 8.dp))
            }

            NearbyEngine.connRequest?.let { ConnRequestDialog(it) }
            NearbyEngine.offerQueue.firstOrNull()?.let { OfferDialog(it) }
        }
    }
}

@Composable
private fun BottomBar(tab: Int, onTab: (Int) -> Unit) {
    val cs = MaterialTheme.colorScheme
    Surface(tonalElevation = 3.dp, shadowElevation = 8.dp, color = cs.surface) {
        Row(Modifier.fillMaxWidth().navigationBarsPadding().height(68.dp), verticalAlignment = Alignment.CenterVertically) {
            NAV.forEachIndexed { i, (label, icon) ->
                Box(Modifier.weight(1f).fillMaxHeight().clickable { onTab(i) }, contentAlignment = Alignment.Center) {
                    if (i == 2) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Box(Modifier.size(44.dp).clip(CircleShape).background(cs.primary), contentAlignment = Alignment.Center) {
                                Icon(icon, label, tint = cs.onPrimary, modifier = Modifier.size(24.dp))
                            }
                            Text(label, fontSize = 11.sp, color = if (tab == i) cs.primary else cs.onSurfaceVariant)
                        }
                    } else {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Icon(icon, label, tint = if (tab == i) cs.primary else cs.onSurfaceVariant)
                            Text(label, fontSize = 11.sp, color = if (tab == i) cs.primary else cs.onSurfaceVariant)
                        }
                    }
                }
            }
        }
    }
}
