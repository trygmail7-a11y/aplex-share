package com.aplex.share.data

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue

/** Files the user has picked to send. Survives tab changes. */
object Selection {
    val items = mutableStateMapOf<String, SendItem>()

    fun isSelected(i: SendItem) = items.containsKey(i.key)
    fun toggle(i: SendItem) { if (isSelected(i)) items.remove(i.key) else items[i.key] = i }
    fun addAll(list: List<SendItem>) { list.forEach { items[it.key] = it } }
    fun removeAll(list: List<SendItem>) { list.forEach { items.remove(it.key) } }
    fun clear() = items.clear()
    fun totalSize(): Long = items.values.sumOf { it.size }
}

/** Small one-way signals from the Activity to Compose. */
object UiBus {
    var goSelected by mutableStateOf(false)
}
