package com.aplex.share.core

import android.annotation.SuppressLint
import android.bluetooth.BluetoothManager
import android.bluetooth.le.AdvertiseCallback
import android.bluetooth.le.AdvertiseData
import android.bluetooth.le.AdvertiseSettings
import android.bluetooth.le.ScanCallback
import android.bluetooth.le.ScanFilter
import android.bluetooth.le.ScanResult
import android.bluetooth.le.ScanSettings
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.ParcelUuid
import android.os.PowerManager
import android.os.SystemClock
import androidx.core.content.ContextCompat
import com.aplex.share.data.Prefs
import java.security.SecureRandom

/**
 * "Touch to connect": every phone sends a tiny Bluetooth LE beacon and listens for the same beacon.
 * When a beacon is very strong (phones almost touching) for a moment, [NearbyEngine.onTouch] fires.
 * Signal strength is only an estimate of distance, so sensitivity can be changed in Profile.
 * Runs only while the screen is on, to save battery.
 */
object Proximity {
    private val SERVICE: ParcelUuid = ParcelUuid.fromString("7a3c1f20-5a1e-4b7d-9c11-a91e5ca4e001")
    private const val MFG_ID = 0xFFFF

    private lateinit var app: Context
    private var started = false
    private var radiosOn = false

    val tokenBytes: ByteArray = ByteArray(4).also { SecureRandom().nextBytes(it) }
    val token: String = tokenBytes.joinToString("") { "%02x".format(it) }

    private class Sight(var ema: Double, var hits: Int, var lastSeen: Long, var armed: Boolean)
    private val sights = HashMap<String, Sight>()

    private val screenReceiver = object : BroadcastReceiver() {
        override fun onReceive(c: Context, i: Intent) {
            if (i.action == Intent.ACTION_SCREEN_ON) startRadios()
            else if (i.action == Intent.ACTION_SCREEN_OFF) stopRadios()
        }
    }

    fun init(ctx: Context) { app = ctx.applicationContext }

    fun start() {
        if (started) { if (!radiosOn) maybeStartRadios(); return }
        started = true
        try {
            ContextCompat.registerReceiver(
                app, screenReceiver,
                IntentFilter().apply { addAction(Intent.ACTION_SCREEN_ON); addAction(Intent.ACTION_SCREEN_OFF) },
                ContextCompat.RECEIVER_NOT_EXPORTED
            )
        } catch (_: Exception) { }
        maybeStartRadios()
    }

    fun stop() {
        if (!started) return
        started = false
        try { app.unregisterReceiver(screenReceiver) } catch (_: Exception) { }
        stopRadios()
    }

    /** Re-apply settings such as Hidden visibility. */
    fun restart() { if (started) { stopRadios(); maybeStartRadios() } }

    private fun maybeStartRadios() {
        val pm = app.getSystemService(PowerManager::class.java)
        if (pm != null && pm.isInteractive) startRadios()
    }

    private val advCb = object : AdvertiseCallback() {}

    private val scanCb = object : ScanCallback() {
        override fun onScanResult(callbackType: Int, result: ScanResult) {
            val data = result.scanRecord?.getManufacturerSpecificData(MFG_ID) ?: return
            if (data.size != 4) return
            val tok = data.joinToString("") { "%02x".format(it) }
            if (tok == token) return
            onSighting(tok, result.rssi)
        }
    }

    @SuppressLint("MissingPermission")
    private fun startRadios() {
        if (radiosOn || !started) return
        try {
            val adapter = app.getSystemService(BluetoothManager::class.java)?.adapter ?: return
            if (!adapter.isEnabled) return
            if (!Prefs.visibilityHidden) {
                val settings = AdvertiseSettings.Builder()
                    .setAdvertiseMode(AdvertiseSettings.ADVERTISE_MODE_LOW_LATENCY)
                    .setTxPowerLevel(AdvertiseSettings.ADVERTISE_TX_POWER_MEDIUM)
                    .setConnectable(false)
                    .build()
                val data = AdvertiseData.Builder()
                    .setIncludeDeviceName(false)
                    .addServiceUuid(SERVICE)
                    .addManufacturerData(MFG_ID, tokenBytes)
                    .build()
                adapter.bluetoothLeAdvertiser?.startAdvertising(settings, data, advCb)
            }
            val filter = ScanFilter.Builder().setServiceUuid(SERVICE).build()
            val scan = ScanSettings.Builder().setScanMode(ScanSettings.SCAN_MODE_LOW_LATENCY).build()
            adapter.bluetoothLeScanner?.startScan(listOf(filter), scan, scanCb)
            radiosOn = true
        } catch (_: Exception) { }
    }

    @SuppressLint("MissingPermission")
    private fun stopRadios() {
        try {
            val adapter = app.getSystemService(BluetoothManager::class.java)?.adapter
            adapter?.bluetoothLeAdvertiser?.stopAdvertising(advCb)
            adapter?.bluetoothLeScanner?.stopScan(scanCb)
        } catch (_: Exception) { }
        radiosOn = false
        sights.clear()
    }

    private fun threshold(): Int = when (Prefs.touchLevel) { 0 -> -42; 2 -> -58; else -> -50 }

    private fun onSighting(tok: String, rssi: Int) {
        val now = SystemClock.elapsedRealtime()
        val th = threshold()
        val s = sights.getOrPut(tok) { Sight(rssi.toDouble(), 0, now, true) }
        if (now - s.lastSeen > 5000) { s.hits = 0; s.armed = true; s.ema = rssi.toDouble() }
        s.lastSeen = now
        s.ema = s.ema * 0.5 + rssi * 0.5
        if (s.ema >= th) s.hits++ else { s.hits = 0; if (s.ema < th - 10) s.armed = true }
        if (s.armed && s.hits >= 3) {
            s.armed = false; s.hits = 0
            NearbyEngine.onTouch(tok)
        }
    }
}
