package com.aplex.share.core

import android.Manifest
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import com.aplex.share.MainActivity
import com.aplex.share.R
import com.aplex.share.data.Direction

object Notifier {
    const val FG_ID = 1
    private const val CH_TRANSFER = "transfer"
    private const val CH_INCOMING = "incoming"
    private lateinit var ctx: Context

    fun init(c: Context) {
        ctx = c.applicationContext
        val nm = ctx.getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel(CH_TRANSFER, "Transfers", NotificationManager.IMPORTANCE_LOW))
        nm.createNotificationChannel(NotificationChannel(CH_INCOMING, "Incoming requests", NotificationManager.IMPORTANCE_HIGH))
    }

    private fun openApp(): PendingIntent = PendingIntent.getActivity(
        ctx, 0,
        Intent(ctx, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_NEW_TASK),
        PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
    )

    private fun canPost() = Build.VERSION.SDK_INT < 33 ||
        ContextCompat.checkSelfPermission(ctx, Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED

    private fun post(id: Int, n: Notification) {
        if (!canPost()) return
        try { ctx.getSystemService(NotificationManager::class.java).notify(id, n) } catch (_: Exception) { }
    }

    /** Used by the foreground service. */
    fun serviceNotification(c: Context): Notification =
        NotificationCompat.Builder(c, CH_TRANSFER)
            .setSmallIcon(R.drawable.ic_stat_share)
            .setContentTitle("Aplex Share")
            .setContentText("Transfer in progress")
            .setOngoing(true)
            .setContentIntent(openApp())
            .build()

    fun updateProgress(t: TransferState) {
        val pct = if (t.total > 0) (t.done * 100 / t.total).toInt() else 0
        val verb = if (t.direction == Direction.SENT) "Sending to" else "Receiving from"
        post(
            FG_ID,
            NotificationCompat.Builder(ctx, CH_TRANSFER)
                .setSmallIcon(R.drawable.ic_stat_share)
                .setContentTitle("$verb ${t.peerName}")
                .setContentText("$pct%  ·  ${formatSize(t.done)} of ${formatSize(t.total)}")
                .setProgress(100, pct, false)
                .setOngoing(true)
                .setOnlyAlertOnce(true)
                .setContentIntent(openApp())
                .build()
        )
    }

    fun incoming(t: TransferState) {
        post(
            2000 + (t.id.hashCode() and 0xfff),
            NotificationCompat.Builder(ctx, CH_INCOMING)
                .setSmallIcon(R.drawable.ic_stat_share)
                .setContentTitle("${t.peerName} wants to send files")
                .setContentText("${t.files.size} file(s) · ${formatSize(t.total)}. Open Aplex Share to accept.")
                .setAutoCancel(true)
                .setContentIntent(openApp())
                .build()
        )
    }

    fun finished(t: TransferState, ok: Boolean) {
        val title = if (ok) "Transfer completed" else "Transfer failed"
        val text = if (ok) "${t.files.size} file(s) · ${formatSize(t.total)} with ${t.peerName}" else (t.error ?: "Something went wrong")
        post(
            3000 + (t.id.hashCode() and 0xfff),
            NotificationCompat.Builder(ctx, CH_TRANSFER)
                .setSmallIcon(R.drawable.ic_stat_share)
                .setContentTitle(title)
                .setContentText(text)
                .setAutoCancel(true)
                .setContentIntent(openApp())
                .build()
        )
    }
}
