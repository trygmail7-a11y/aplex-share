package com.aplex.share.core

import android.Manifest
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import com.aplex.share.MainActivity
import com.aplex.share.R
import com.aplex.share.data.Direction
import com.aplex.share.data.Prefs

object Notifier {
    const val FG_ID = 1
    private const val CH_TRANSFER = "transfer"
    private const val CH_INCOMING = "incoming"
    private const val CH_NEARBY = "nearby"
    private const val CH_QUIET = "nearby_quiet"

    const val ACT_ACCEPT_CONN = "com.aplex.share.ACCEPT_CONN"
    const val ACT_REJECT_CONN = "com.aplex.share.REJECT_CONN"
    const val ACT_ACCEPT_OFFER = "com.aplex.share.ACCEPT_OFFER"
    const val ACT_DECLINE_OFFER = "com.aplex.share.DECLINE_OFFER"
    const val ACT_CONNECT = "com.aplex.share.CONNECT"

    private lateinit var ctx: Context

    fun init(c: Context) {
        ctx = c.applicationContext
        val nm = ctx.getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel(CH_TRANSFER, "Quick Share and transfers", NotificationManager.IMPORTANCE_LOW))
        nm.createNotificationChannel(NotificationChannel(CH_INCOMING, "Incoming requests", NotificationManager.IMPORTANCE_HIGH))
        nm.createNotificationChannel(NotificationChannel(CH_NEARBY, "Nearby devices", NotificationManager.IMPORTANCE_HIGH))
        nm.createNotificationChannel(NotificationChannel(CH_QUIET, "Devices in range", NotificationManager.IMPORTANCE_LOW))
    }

    private fun openApp(tab: Int): PendingIntent = PendingIntent.getActivity(
        ctx, 100 + tab,
        Intent(ctx, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_NEW_TASK).putExtra("tab", tab),
        PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
    )

    private fun action(act: String, id: String, nid: Int): PendingIntent = PendingIntent.getBroadcast(
        ctx, (act + id).hashCode(),
        Intent(ctx, ActionReceiver::class.java).setAction(act).putExtra("id", id).putExtra("nid", nid),
        PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
    )

    private fun canPost() = Build.VERSION.SDK_INT < 33 ||
        ContextCompat.checkSelfPermission(ctx, Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED

    private fun post(id: Int, n: Notification) {
        if (!canPost()) return
        try { ctx.getSystemService(NotificationManager::class.java).notify(id, n) } catch (_: Exception) { }
    }

    /** The always-on notification of the foreground service. */
    fun serviceNotification(c: Context): Notification =
        NotificationCompat.Builder(c, CH_TRANSFER)
            .setSmallIcon(R.drawable.ic_stat_share)
            .setContentTitle("Aplex Share")
            .setContentText(if (Prefs.nearbyEnabled) "Quick Share is on · visible as ${Prefs.deviceName}" else "Transfer in progress")
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setContentIntent(openApp(0))
            .build()

    fun idle() = post(FG_ID, serviceNotification(ctx))

    fun updateProgress(t: TransferState) {
        val pct = if (t.total > 0) (t.done * 100 / t.total).toInt() else 0
        val verb = if (t.direction == Direction.SENT) "Sending to" else "Receiving from"
        post(
            FG_ID,
            NotificationCompat.Builder(ctx, CH_TRANSFER)
                .setSmallIcon(R.drawable.ic_stat_share)
                .setContentTitle("$verb ${t.peerName}")
                .setContentText("$pct%  ·  ${formatSize(t.done)} of ${formatSize(t.total)}")
                .setProgress(100, pct, false)
                .setOngoing(true)
                .setOnlyAlertOnce(true)
                .setContentIntent(openApp(0))
                .build()
        )
    }

    /** Heads-up at the top of the screen when a phone with Aplex Share is close by. */
    fun nearby(endpointId: String, name: String) {
        val nid = 4000 + (name.hashCode() and 0xfff)
        post(
            nid,
            NotificationCompat.Builder(ctx, CH_QUIET)
                .setSmallIcon(R.drawable.ic_stat_share)
                .setContentTitle("$name is in range")
                .setContentText("Touch the phones together to connect, or tap Connect.")
                .setPriority(NotificationCompat.PRIORITY_LOW)
                .setAutoCancel(true)
                .setTimeoutAfter(90_000)
                .setContentIntent(openApp(1))
                .addAction(0, "Send files", openApp(1))
                .addAction(0, "Connect", action(ACT_CONNECT, endpointId, nid))
                .build()
        )
    }

    fun connRequest(r: ConnRequest) {
        val nid = 5000
        post(
            nid,
            NotificationCompat.Builder(ctx, CH_INCOMING)
                .setSmallIcon(R.drawable.ic_stat_share)
                .setContentTitle("${r.name} wants to connect")
                .setContentText("Code ${r.digits}. Make sure it matches on both phones.")
                .setPriority(NotificationCompat.PRIORITY_HIGH)
                .setAutoCancel(true)
                .setContentIntent(openApp(0))
                .addAction(0, "Accept", action(ACT_ACCEPT_CONN, r.id, nid))
                .addAction(0, "Decline", action(ACT_REJECT_CONN, r.id, nid))
                .build()
        )
    }

    fun connected(name: String) {
        post(
            5001,
            NotificationCompat.Builder(ctx, CH_INCOMING)
                .setSmallIcon(R.drawable.ic_stat_share)
                .setContentTitle("Connected to $name")
                .setContentText("Tap to choose files to send.")
                .setPriority(NotificationCompat.PRIORITY_HIGH)
                .setAutoCancel(true)
                .setContentIntent(openApp(1))
                .build()
        )
    }

    fun incoming(t: TransferState) {
        val nid = 2000 + (t.id.hashCode() and 0xfff)
        post(
            nid,
            NotificationCompat.Builder(ctx, CH_INCOMING)
                .setSmallIcon(R.drawable.ic_stat_share)
                .setContentTitle("${t.peerName} wants to send files")
                .setContentText("${t.files.size} file(s) · ${formatSize(t.total)}")
                .setPriority(NotificationCompat.PRIORITY_HIGH)
                .setAutoCancel(true)
                .setContentIntent(openApp(0))
                .addAction(0, "Accept", action(ACT_ACCEPT_OFFER, t.id, nid))
                .addAction(0, "Decline", action(ACT_DECLINE_OFFER, t.id, nid))
                .build()
        )
    }

    fun cancelIncoming(tid: String) {
        try { ctx.getSystemService(NotificationManager::class.java).cancel(2000 + (tid.hashCode() and 0xfff)) } catch (_: Exception) { }
    }

    fun finished(t: TransferState, ok: Boolean) {
        val title = if (ok) "Transfer completed" else "Transfer failed"
        val text = if (ok) "${t.files.size} file(s) · ${formatSize(t.total)} with ${t.peerName}" else (t.error ?: "Something went wrong")
        post(
            3000 + (t.id.hashCode() and 0xfff),
            NotificationCompat.Builder(ctx, CH_TRANSFER)
                .setSmallIcon(R.drawable.ic_stat_share)
                .setContentTitle(title)
                .setContentText(text)
                .setAutoCancel(true)
                .setContentIntent(openApp(3))
                .build()
        )
    }
}
