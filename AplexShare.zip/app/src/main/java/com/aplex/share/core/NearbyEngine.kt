package com.aplex.share.core

import android.content.Context
import android.net.Uri
import android.os.Environment
import android.os.ParcelFileDescriptor
import android.os.StatFs
import android.os.SystemClock
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import com.aplex.share.data.*
import com.google.android.gms.common.api.ApiException
import com.google.android.gms.nearby.Nearby
import com.google.android.gms.nearby.connection.*
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.security.MessageDigest
import java.security.SecureRandom
import java.util.UUID

enum class PeerState { FOUND, CONNECTING, CONNECTED, FAILED }

data class Peer(val id: String, val name: String, val avatar: Int, val state: PeerState)

data class ConnRequest(val id: String, val name: String, val digits: String, val incoming: Boolean)

class QrSession(val pid: String, val secret: String, val expiresAt: Long)

private class QrTarget(val pid: String, val secret: String)

private class PeerInfo(val avatar: Int, val tag: String, val name: String, val tok: String = "")

private class PendingOffer(val endpointId: String) {
    var n = -1
    val files = mutableListOf<FileEntry>()
}

class TransferState(val id: String, val direction: Direction, val endpointId: String, val peerName: String) {
    var files by mutableStateOf<List<FileEntry>>(emptyList()); private set
    var total by mutableLongStateOf(0L); private set
    var status by mutableStateOf(TStatus.PREPARING)
    var startedAt by mutableLongStateOf(System.currentTimeMillis())
    var endedAt by mutableLongStateOf(0L)
    var done by mutableLongStateOf(0L)
    var speed by mutableLongStateOf(0L)
    var error by mutableStateOf<String?>(null)
    val fileStatus = mutableStateMapOf<Int, TStatus>()
    val fileProgress = mutableStateMapOf<Int, Long>()
    val savedUris = mutableMapOf<Int, String>()
    val savedSha = mutableMapOf<Int, String>()
    var items: List<SendItem> = emptyList()
    var completedBytes = 0L
    var doneCount = 0
    var lastTick = 0L
    var lastBytes = 0L
    var inFlight = 0
    var nextIdx = 0
    val finished = HashSet<Int>()

    val isActive: Boolean get() = status == TStatus.PREPARING || status == TStatus.WAITING || status == TStatus.ACTIVE

    fun assignFiles(l: List<FileEntry>) { files = l; total = l.sumOf { it.size } }
}

/**
 * All nearby discovery, pairing and file transfer logic.
 *
 * Wire protocol (small JSON messages over Nearby BYTES payloads, files over FILE payloads):
 *  offer / files  sender -> receiver   file list (names and sizes only)
 *  accept/decline receiver -> sender   user decision
 *  map            sender -> receiver   links a FILE payload id to a file index and carries its SHA-256
 *  done           receiver -> sender   all files saved and checksums verified (ok true/false)
 *  cancel         either direction     stop (r = reason, empty when the user cancelled)
 *  qrauth         scanner -> advertiser proves the scanner saw the QR secret
 */
object NearbyEngine {
    const val SERVICE_ID = "com.aplex.share.v1"
    private const val QR_TTL = 5 * 60_000L
    private const val MAX_FILES = 5000
    private const val WINDOW = 6

    private lateinit var app: Context
    private val client by lazy { Nearby.getConnectionsClient(app) }
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)
    private val rnd = SecureRandom()
    // POINT_TO_POINT lets Nearby upgrade the link to Wi-Fi Direct / hotspot (fast). CLUSTER stays on slow links.
    private val STRATEGY = Strategy.P2P_POINT_TO_POINT

    // ---- UI state ----
    val peers = mutableStateMapOf<String, Peer>()
    val transfers = mutableStateMapOf<String, TransferState>()
    val offerQueue = mutableStateListOf<TransferState>()
    var permsOk by mutableStateOf(false); private set
    var advertising by mutableStateOf(false); private set
    var discovering by mutableStateOf(false); private set
    var connRequest by mutableStateOf<ConnRequest?>(null); private set
    var qrSession by mutableStateOf<QrSession?>(null); private set
    var receiveMode by mutableStateOf(false); private set
    var lastCompleted by mutableStateOf<TransferState?>(null)
    var focusTransferId by mutableStateOf<String?>(null)
    var message by mutableStateOf<String?>(null)
    var pairedName by mutableStateOf<String?>(null)
    /** Set while the app is open and a phone just connected: shows the Send / Receive choice. */
    var actionPeer by mutableStateOf<Peer?>(null)
    /** (token, name) of a phone that is almost touching this one: shows "Connect / Not now". */
    var touchPeer by mutableStateOf<Pair<String, String>?>(null)
    private val awaitingTouch = HashMap<String, Long>()
    private var awaitingConnect: String? = null

    // ---- internal state ----
    private var appVisible = false
    private var discoveryWanted = false
    private var qrTarget: QrTarget? = null
    private val qrOutgoing = HashSet<String>()
    private val trusted = HashSet<String>()
    private val tentative = HashSet<String>()
    private val found = HashSet<String>()
    private val info = HashMap<String, PeerInfo>()
    private val sendAfterConnect = HashMap<String, List<SendItem>>()
    private val pendingOffers = HashMap<String, PendingOffer>()
    private val payloadToFile = HashMap<Long, Pair<String, Int>>()
    private val payloadRefs = HashMap<Long, Payload>()
    private val lastUpdate = HashMap<Long, PayloadTransferUpdate>()

    fun init(ctx: Context) { app = ctx.applicationContext; Proximity.init(ctx) }

    private fun now() = System.currentTimeMillis()
    private fun randomHex(bytes: Int) = ByteArray(bytes).also { rnd.nextBytes(it) }.joinToString("") { "%02x".format(it) }

    // ---------------- lifecycle ----------------

    fun refreshPerms(ctx: Context) { permsOk = Permissions.has(ctx, Permissions.nearby()) }

    fun onAppVisible(v: Boolean) {
        appVisible = v
        if (v) { applyAdvertising(); applyDiscovery() } else if (!hasActive() && !Prefs.nearbyEnabled) stopRadios() else { applyAdvertising(); applyDiscovery() }
    }

    fun changeDiscoveryWanted(w: Boolean) { discoveryWanted = w; applyDiscovery() }
    fun changeReceiveMode(on: Boolean) { if (receiveMode != on) { receiveMode = on; applyAdvertising() } }
    fun settingsChanged() { applyAdvertising(); applyDiscovery(); Proximity.restart(); refreshService() }

    private fun hasActive() = transfers.values.any { it.isActive }

    private fun stopRadios() {
        try { client.stopAdvertising(); client.stopDiscovery() } catch (_: Exception) { }
        advertising = false; discovering = false
        found.clear()
        peers.keys.toList().forEach { k -> peers[k]?.let { if (it.state == PeerState.FOUND || it.state == PeerState.FAILED) peers.remove(k) } }
    }

    // ---------------- advertising / discovery ----------------

    private fun encodeName(tag: String) = "AX|${Prefs.avatar}|$tag|${Proximity.token}|${Prefs.deviceName.take(30).replace('|', ' ')}"

    private fun parse(s: String): PeerInfo? {
        val p = s.split("|", limit = 5)
        if (p.size < 5 || p[0] != "AX") return null
        return PeerInfo(p[1].toIntOrNull() ?: 0, p[2], p[4], p[3])
    }

    private var advName: String? = null

    fun applyAdvertising() {
        if (!permsOk) return
        if (!appVisible && !Prefs.nearbyEnabled) return
        val q = qrSession?.takeIf { it.expiresAt > now() }
        val visible = !Prefs.visibilityHidden || q != null || receiveMode
        val target = if (Prefs.nearbyEnabled && visible) encodeName(q?.pid ?: "-") else null
        if (target == advName && (target == null || advertising)) return
        try { client.stopAdvertising() } catch (_: Exception) { }
        advertising = false
        advName = null
        if (target == null) return
        client.startAdvertising(
            target, SERVICE_ID, connCb,
            AdvertisingOptions.Builder().setStrategy(STRATEGY).build()
        ).addOnSuccessListener { advertising = true; advName = target }
            .addOnFailureListener { reportError(it); if (advertising) advName = target }
    }

    private fun applyDiscovery() {
        val bg = !appVisible && Prefs.nearbyEnabled
        val fg = appVisible && discoveryWanted && Prefs.nearbyEnabled
        val want = permsOk && (bg || fg || qrTarget != null || awaitingTouch.isNotEmpty() || awaitingConnect != null)
        if (want && !discovering) {
            client.startDiscovery(
                SERVICE_ID, discCb,
                DiscoveryOptions.Builder().setStrategy(STRATEGY).build()
            ).addOnSuccessListener { discovering = true }
                .addOnFailureListener { reportError(it) }
        } else if (!want && discovering) {
            try { client.stopDiscovery() } catch (_: Exception) { }
            discovering = false
            found.clear()
            peers.keys.toList().forEach { k -> peers[k]?.let { if (it.state == PeerState.FOUND || it.state == PeerState.FAILED) peers.remove(k) } }
        }
    }

    private val discCb = object : EndpointDiscoveryCallback() {
        override fun onEndpointFound(id: String, i: DiscoveredEndpointInfo) {
            val p = parse(i.endpointName) ?: return
            info[id] = p
            found.add(id)
            val st = peers[id]?.state
            if (st == PeerState.CONNECTED || st == PeerState.CONNECTING) return
            peers[id] = Peer(id, p.name, p.avatar, PeerState.FOUND)
            if (p.tok.isNotEmpty()) {
                if (awaitingConnect == p.tok) { awaitingConnect = null; connect(id) }
                else if (awaitingTouch.remove(p.tok) != null) showTouch(id, p.tok, p.name)
            }
            val tgt = qrTarget
            if (tgt != null && p.tag == tgt.pid) connect(id, qr = true)
            if (!appVisible) notifyNearby(p)
        }

        override fun onEndpointLost(id: String) {
            found.remove(id)
            val p = peers[id] ?: return
            if (p.state == PeerState.FOUND || p.state == PeerState.FAILED) peers.remove(id)
        }
    }

    private fun reportError(e: Exception) {
        val code = (e as? ApiException)?.statusCode
        when (code) {
            ConnectionsStatusCodes.STATUS_ALREADY_ADVERTISING -> advertising = true
            ConnectionsStatusCodes.STATUS_ALREADY_DISCOVERING -> discovering = true
            ConnectionsStatusCodes.STATUS_OUT_OF_ORDER_API_CALL -> { }
            ConnectionsStatusCodes.STATUS_BLUETOOTH_ERROR, ConnectionsStatusCodes.STATUS_RADIO_ERROR ->
                message = "Turn on Wi-Fi and Bluetooth (and Location on Android 11 or older), then try again."
            17 -> message = "This phone doesn't support nearby sharing. It needs Google Play services."
            else -> message = "Couldn't start nearby sharing. Check Wi-Fi and Bluetooth and try again."
        }
    }

    // ---------------- connecting ----------------

    fun connect(id: String, qr: Boolean = false, attempt: Int = 0) {
        val p = peers[id] ?: return
        if (p.state == PeerState.CONNECTING || p.state == PeerState.CONNECTED) return
        // POINT_TO_POINT keeps one live link; drop an idle old one first.
        if (!hasActive()) peers.values.filter { it.state == PeerState.CONNECTED && it.id != id }.forEach { disconnect(it.id) }
        peers[id] = p.copy(state = PeerState.CONNECTING)
        if (qr) qrOutgoing.add(id)
        client.requestConnection(encodeName(if (qr) "Q" else "-"), id, connCb)
            .addOnFailureListener { e ->
                val code = (e as? ApiException)?.statusCode
                if (code == ConnectionsStatusCodes.STATUS_ALREADY_CONNECTED_TO_ENDPOINT) {
                    peers[id]?.let { peers[id] = it.copy(state = PeerState.CONNECTED) }
                    trusted.add(id)
                } else if (attempt < 1) {
                    peers[id]?.let { peers[id] = it.copy(state = PeerState.FOUND) }
                    scope.launch { delay(1200); connect(id, qr, attempt + 1) }
                } else {
                    sendAfterConnect.remove(id); qrOutgoing.remove(id)
                    peers[id]?.let { peers[id] = it.copy(state = PeerState.FAILED) }
                    message = "Couldn't connect. Check Bluetooth, Wi-Fi and Location are on for both phones."
                }
            }
    }

    fun queueSend(id: String, items: List<SendItem>) { sendAfterConnect[id] = items }

    fun acceptConnection() {
        QuickPopup.dismiss()
        val r = connRequest ?: return
        connRequest = null
        client.acceptConnection(r.id, payloadCb)
    }

    fun rejectConnection() {
        QuickPopup.dismiss()
        val r = connRequest ?: return
        connRequest = null
        client.rejectConnection(r.id)
        sendAfterConnect.remove(r.id)
        peers[r.id]?.let { peers[r.id] = it.copy(state = if (r.id in found) PeerState.FOUND else PeerState.FAILED) }
    }

    fun disconnect(id: String) {
        try { client.disconnectFromEndpoint(id) } catch (_: Exception) { }
        handleDisconnected(id)
    }

    private val connCb = object : ConnectionLifecycleCallback() {
        override fun onConnectionInitiated(id: String, ci: ConnectionInfo) {
            val p = parse(ci.endpointName)
            if (p != null) info[id] = p
            val name = p?.name ?: ci.endpointName
            // Scanner side: the user already chose this device by scanning its QR.
            if (!ci.isIncomingConnection && id in qrOutgoing) {
                client.acceptConnection(id, payloadCb); return
            }
            // Advertiser side with a live QR: accept tentatively, require the secret within 10 s.
            val s = qrSession
            if (ci.isIncomingConnection && s != null && s.expiresAt > now() && p?.tag == "Q") {
                tentative.add(id)
                client.acceptConnection(id, payloadCb)
                scope.launch {
                    delay(10_000)
                    if (id in tentative) { tentative.remove(id); disconnect(id) }
                }
                return
            }
            val req = ConnRequest(id, name, ci.authenticationDigits, ci.isIncomingConnection)
            connRequest = req
            touchPeer = null
            if (!appVisible && !QuickPopup.showRequest(app, req)) Notifier.connRequest(req)
            scope.launch {
                delay(30_000) // connection timeout
                if (connRequest?.id == id) rejectConnection()
            }
        }

        override fun onConnectionResult(id: String, r: ConnectionResolution) {
            if (connRequest?.id == id) connRequest = null
            val pi = info[id]
            val name = pi?.name ?: "Device"
            if (r.status.isSuccess) {
                peers[id] = Peer(id, name, pi?.avatar ?: 0, PeerState.CONNECTED)
                if (id !in tentative) {
                    trusted.add(id)
                    pairedName = name
                    if (sendAfterConnect[id] == null) promptActions(id, name)
                }
                val tgt = qrTarget
                if (tgt != null && id in qrOutgoing) {
                    qrOutgoing.remove(id)
                    sendMsg(id, JSONObject().put("t", "qrauth").put("sec", tgt.secret))
                    qrTarget = null
                    applyDiscovery()
                }
                sendAfterConnect.remove(id)?.let { send(id, it) }
            } else {
                qrOutgoing.remove(id); tentative.remove(id); sendAfterConnect.remove(id)
                peers[id]?.let { peers[id] = it.copy(state = if (id in found) PeerState.FOUND else PeerState.FAILED) }
                message = if (r.status.statusCode == ConnectionsStatusCodes.STATUS_CONNECTION_REJECTED)
                    "$name declined the connection." else "Couldn't connect to $name."
            }
        }

        override fun onDisconnected(id: String) { handleDisconnected(id) }
    }

    private fun handleDisconnected(id: String) {
        trusted.remove(id); tentative.remove(id); qrOutgoing.remove(id)
        val cur = peers[id]
        if (cur != null) {
            if (id in found) peers[id] = cur.copy(state = PeerState.FOUND) else peers.remove(id)
        }
        transfers.values.filter { it.endpointId == id && it.isActive }
            .forEach { fail(it, "Connection lost. Move closer and try again.", notifyPeer = false) }
        offerQueue.filter { it.endpointId == id }.forEach { offerQueue.remove(it) }
    }

    // ---------------- Quick Share helpers (background, notifications) ----------------

    private val nearbyNotified = HashMap<String, Long>()

    private fun notifyNearby(p: PeerInfo) {
        val last = nearbyNotified[p.name] ?: 0L
        if (now() - last < 120_000) return
        nearbyNotified[p.name] = now()
        val id = info.entries.firstOrNull { it.value === p }?.key ?: return
        Notifier.nearby(id, p.name)
    }

    /** After two phones connect: ask Send or Receive (in-app dialog, or pop-up over other apps). */
    private fun promptActions(id: String, name: String) {
        if (appVisible) actionPeer = peers[id] ?: Peer(id, name, 0, PeerState.CONNECTED)
        else if (!QuickPopup.showChoice(app, id, name)) Notifier.connected(name)
    }

    fun connectById(id: String) { if (peers[id] != null) connect(id) else connectByTok(id) }

    /** Two phones are almost touching. Show Connect / Not now on this phone. */
    fun onTouch(tok: String) {
        if (!permsOk) return
        if (peers.values.any { it.state == PeerState.CONNECTED && info[it.id]?.tok == tok }) return
        val ep = info.entries.firstOrNull { it.value.tok == tok && it.key in found }
        if (ep != null) { showTouch(ep.key, tok, ep.value.name); return }
        awaitingTouch[tok] = now()
        applyDiscovery()
        scope.launch {
            delay(3000)
            if (awaitingTouch.remove(tok) != null) showTouch(tok, tok, "Nearby device")
        }
    }

    private fun showTouch(epId: String, tok: String, name: String) {
        if (peers.values.any { it.state == PeerState.CONNECTED && info[it.id]?.tok == tok }) return
        if (appVisible) touchPeer = tok to name
        else if (!QuickPopup.showTouch(app, tok, name)) Notifier.nearby(epId, name)
    }

    fun connectByTok(tok: String) {
        touchPeer = null
        val ep = info.entries.firstOrNull { it.value.tok == tok && it.key in found }
        if (ep != null) { connect(ep.key); return }
        awaitingConnect = tok
        applyDiscovery()
        scope.launch {
            delay(8000)
            if (awaitingConnect == tok) {
                awaitingConnect = null
                message = "Couldn't reach that device. Hold the phones together and try again."
                applyDiscovery()
            }
        }
    }
    fun acceptOfferById(tid: String) { offerQueue.firstOrNull { it.id == tid }?.let { acceptOffer(it) } }
    fun declineOfferById(tid: String) { offerQueue.firstOrNull { it.id == tid }?.let { declineOffer(it) } }

    fun restartDiscovery() {
        try { client.stopDiscovery() } catch (_: Exception) { }
        discovering = false
        found.clear()
        applyDiscovery()
    }

    /** Called after reboot so Quick Share is on again without opening the app. */
    fun backgroundStart() {
        if (!Prefs.nearbyEnabled || !permsOk) return
        applyAdvertising(); applyDiscovery(); refreshService()
    }

    // ---------------- QR pairing ----------------

    fun createQr(): QrSession {
        val s = QrSession(randomHex(3), randomHex(12), now() + QR_TTL)
        qrSession = s
        applyAdvertising()
        scope.launch {
            delay(QR_TTL + 500)
            if (qrSession === s) { qrSession = null; applyAdvertising() }
        }
        return s
    }

    fun clearQr() { if (qrSession != null) { qrSession = null; applyAdvertising() } }

    fun qrString(s: QrSession) = "aplex://pair?v=1&pid=${s.pid}&sec=${s.secret}&exp=${s.expiresAt}"

    fun handleQr(text: String) {
        val u = try { Uri.parse(text) } catch (_: Exception) { null }
        if (u == null || u.scheme != "aplex" || u.host != "pair") { message = "That QR code isn't from Aplex Share."; return }
        val pid = u.getQueryParameter("pid")
        val sec = u.getQueryParameter("sec")
        val exp = u.getQueryParameter("exp")?.toLongOrNull()
        if (pid.isNullOrBlank() || sec.isNullOrBlank() || exp == null) { message = "That QR code isn't valid."; return }
        if (exp < now()) { message = "This QR code has expired. Ask for a new one."; return }
        val tgt = QrTarget(pid, sec)
        qrTarget = tgt
        message = "Looking for that device…"
        applyDiscovery()
        // Already seen in a running discovery?
        info.entries.firstOrNull { it.value.tag == pid && it.key in found }?.let { connect(it.key, qr = true) }
        scope.launch {
            delay(30_000)
            if (qrTarget === tgt) {
                qrTarget = null
                message = "Couldn't find that device. Ask for a new QR code."
                applyDiscovery()
            }
        }
    }

    // ---------------- messaging ----------------

    private fun sendMsg(id: String, o: JSONObject) {
        client.sendPayload(id, Payload.fromBytes(o.toString().toByteArray(Charsets.UTF_8)))
    }

    private val payloadCb = object : PayloadCallback() {
        override fun onPayloadReceived(id: String, p: Payload) { onPayload(id, p) }
        override fun onPayloadTransferUpdate(id: String, u: PayloadTransferUpdate) { onUpdate(u) }
    }

    private fun onPayload(endpointId: String, p: Payload) {
        when (p.type) {
            Payload.Type.BYTES -> {
                val b = p.asBytes() ?: return
                if (b.size > 40_000) return
                onMessage(endpointId, String(b, Charsets.UTF_8))
            }
            Payload.Type.FILE -> {
                if (endpointId !in trusted) { client.cancelPayload(p.id); return }
                payloadRefs[p.id] = p
                applyUpdate(p.id)
            }
        }
    }

    private fun onMessage(id: String, text: String) {
        val j = try { JSONObject(text) } catch (_: Exception) { return }
        val type = j.optString("t")
        if (type == "qrauth") { onQrAuth(id, j.optString("sec")); return }
        if (id !in trusted) return
        val tid = j.optString("id").take(64)
        when (type) {
            "offer" -> {
                val p = pendingOffers.getOrPut(tid) { PendingOffer(id) }
                p.n = j.optInt("n", -1)
                checkOffer(tid, p)
            }
            "files" -> {
                val p = pendingOffers.getOrPut(tid) { PendingOffer(id) }
                val arr = j.optJSONArray("f") ?: return
                for (k in 0 until arr.length()) {
                    if (p.files.size >= MAX_FILES) break
                    val o = arr.optJSONObject(k) ?: continue
                    val rel = Storage.sanitize(o.optString("p", o.optString("n")))
                    p.files.add(
                        FileEntry(
                            o.optInt("i", -1), rel.substringAfterLast('/'), rel,
                            o.optLong("s", -1).coerceAtLeast(0), o.optString("m", "application/octet-stream").take(100)
                        )
                    )
                }
                checkOffer(tid, p)
            }
            "accept" -> onAccepted(tid)
            "decline" -> transfers[tid]?.let { if (it.isActive) endTransfer(it, TStatus.DECLINED, "${it.peerName} declined the files.") }
            "cancel" -> transfers[tid]?.let {
                if (it.isActive) {
                    cancelPayloadsOf(it)
                    val r = j.optString("r")
                    if (r.isEmpty()) endTransfer(it, TStatus.CANCELLED, "Cancelled by ${it.peerName}") else endTransfer(it, TStatus.FAILED, r)
                }
            }
            "sha" -> {
                val t = transfers[tid] ?: return
                if (t.direction != Direction.RECEIVED) return
                val idx = j.optInt("i", -1)
                if (idx !in t.files.indices) return
                t.files[idx].sha = j.optString("sha").take(64)
                if (t.savedSha.containsKey(idx)) verifyFile(t, idx)
            }
            "map" -> onMap(tid, j)
            "done" -> transfers[tid]?.let {
                if (it.isActive && it.direction == Direction.SENT) {
                    if (j.optBoolean("ok")) { it.done = it.total; endTransfer(it, TStatus.DONE, null) }
                    else fail(it, "The other phone couldn't save or verify the files.", notifyPeer = false)
                }
            }
        }
    }

    private fun onQrAuth(id: String, sec: String) {
        val s = qrSession
        val ok = id in tentative && s != null && s.expiresAt > now() &&
            MessageDigest.isEqual(sec.toByteArray(), s.secret.toByteArray())
        if (ok) {
            tentative.remove(id); trusted.add(id)
            pairedName = info[id]?.name ?: "Device"
            promptActions(id, pairedName ?: "Device")
            qrSession = null // single use
            applyAdvertising()
        } else {
            tentative.remove(id)
            disconnect(id)
        }
    }

    // ---------------- sending ----------------

    fun send(endpointId: String, items: List<SendItem>) {
        if (items.isEmpty()) return
        val t = TransferState(UUID.randomUUID().toString().take(12), Direction.SENT, endpointId, peers[endpointId]?.name ?: info[endpointId]?.name ?: "Device")
        t.items = items
        t.assignFiles(items.mapIndexed { i, it -> FileEntry(i, it.name, Storage.sanitize(it.relPath), it.size, it.mime) })
        t.status = TStatus.WAITING
        transfers[t.id] = t
        Selection.clear()
        focusTransferId = t.id
        refreshService()

        sendMsg(endpointId, JSONObject().put("t", "offer").put("id", t.id).put("n", items.size).put("total", t.total))
        var batch = JSONArray(); var len = 0
        fun flush() {
            if (batch.length() > 0) sendMsg(endpointId, JSONObject().put("t", "files").put("id", t.id).put("f", batch))
            batch = JSONArray(); len = 0
        }
        for (f in t.files) {
            val o = JSONObject().put("i", f.idx).put("n", f.name).put("p", f.relPath).put("s", f.size).put("m", f.mime)
            val l = o.toString().length
            if (len + l > 9000) flush()
            batch.put(o); len += l
        }
        flush()

        scope.launch {
            delay(90_000)
            if (t.status == TStatus.WAITING) fail(t, "${t.peerName} didn't respond.", notifyPeer = true)
        }
    }

    private fun onAccepted(tid: String) {
        val t = transfers[tid] ?: return
        if (t.direction != Direction.SENT || t.status != TStatus.WAITING) return
        t.status = TStatus.ACTIVE
        t.startedAt = now()
        pump(t)
    }

    private fun pump(t: TransferState) {
        while (t.status == TStatus.ACTIVE && t.inFlight < WINDOW && t.nextIdx < t.files.size) {
            val idx = t.nextIdx++
            t.inFlight++
            startFile(t, idx)
        }
    }

    private fun startFile(t: TransferState, idx: Int) {
        scope.launch {
            val item = t.items[idx]
            val pfd = withContext(Dispatchers.IO) {
                runCatching { app.contentResolver.openFileDescriptor(item.uri, "r") ?: error("open") }.getOrNull()
            }
            if (t.status != TStatus.ACTIVE) { pfd?.close(); return@launch }
            if (pfd == null) { fail(t, "Couldn't read ${item.name}.", notifyPeer = true); return@launch }
            val payload = Payload.fromFile(pfd)
            payloadToFile[payload.id] = t.id to idx
            payloadRefs[payload.id] = payload
            t.fileStatus[idx] = TStatus.ACTIVE
            sendMsg(t.endpointId, JSONObject().put("t", "map").put("id", t.id).put("i", idx).put("pid", payload.id))
            client.sendPayload(t.endpointId, payload)
            // Checksum is computed while the file is already flying, so it never slows the transfer.
            val sha = withContext(Dispatchers.IO) { runCatching { Storage.sha256(app, item.uri) }.getOrNull() }
            if (!t.isActive) return@launch
            if (sha == null) fail(t, "Couldn't read ${item.name}.", notifyPeer = true)
            else sendMsg(t.endpointId, JSONObject().put("t", "sha").put("id", t.id).put("i", idx).put("sha", sha))
        }
    }

    // ---------------- receiving ----------------

    private fun checkOffer(tid: String, p: PendingOffer) {
        if (p.n < 1 || p.n > MAX_FILES || p.files.size < p.n) return
        pendingOffers.remove(tid)
        val list = p.files.sortedBy { it.idx }.take(p.n)
        if (list.withIndex().any { (k, f) -> f.idx != k }) return // malformed
        val t = TransferState(tid, Direction.RECEIVED, p.endpointId, info[p.endpointId]?.name ?: "Device")
        t.assignFiles(list)
        t.status = TStatus.WAITING
        offerQueue.add(t)
        Notifier.incoming(t)
        if (!appVisible) QuickPopup.showOffer(app, t)
    }

    fun acceptOffer(t: TransferState) {
        offerQueue.remove(t)
        Notifier.cancelIncoming(t.id)
        QuickPopup.dismiss()
        val free = try { StatFs(Environment.getExternalStorageDirectory().path).availableBytes } catch (_: Exception) { Long.MAX_VALUE }
        if (free < t.total + 50L * 1024 * 1024) {
            message = "Not enough storage space for these files."
            t.error = "Not enough storage"
            sendMsg(t.endpointId, JSONObject().put("t", "decline").put("id", t.id))
            t.status = TStatus.FAILED
            transfers[t.id] = t
            saveRecord(t)
            return
        }
        transfers[t.id] = t
        t.status = TStatus.ACTIVE
        t.startedAt = now()
        focusTransferId = t.id
        refreshService()
        sendMsg(t.endpointId, JSONObject().put("t", "accept").put("id", t.id))
    }

    fun declineOffer(t: TransferState) {
        offerQueue.remove(t)
        Notifier.cancelIncoming(t.id)
        QuickPopup.dismiss()
        sendMsg(t.endpointId, JSONObject().put("t", "decline").put("id", t.id))
        t.status = TStatus.DECLINED
        t.endedAt = now()
        saveRecord(t)
    }

    private fun onMap(tid: String, j: JSONObject) {
        val t = transfers[tid] ?: return
        if (t.direction != Direction.RECEIVED || t.status != TStatus.ACTIVE) return
        val idx = j.optInt("i", -1)
        if (idx !in t.files.indices) return
        val pid = j.optLong("pid", 0L)
        if (pid == 0L) return
        t.fileStatus[idx] = TStatus.ACTIVE
        payloadToFile[pid] = tid to idx
        applyUpdate(pid)
    }

    // ---------------- progress ----------------

    private fun onUpdate(u: PayloadTransferUpdate) {
        lastUpdate[u.payloadId] = u
        applyUpdate(u.payloadId)
    }

    private fun applyUpdate(pid: Long) {
        val u = lastUpdate[pid] ?: return
        val (tid, idx) = payloadToFile[pid] ?: return
        val t = transfers[tid] ?: return
        if (!t.isActive) return
        when (u.status) {
            PayloadTransferUpdate.Status.IN_PROGRESS -> {
                if (idx !in t.finished) { t.fileProgress[idx] = u.bytesTransferred; recompute(t) }
            }
            PayloadTransferUpdate.Status.SUCCESS -> if (t.finished.add(idx)) onFileTransferred(t, idx, pid)
            PayloadTransferUpdate.Status.FAILURE -> fail(t, "The transfer was interrupted.", notifyPeer = true)
            PayloadTransferUpdate.Status.CANCELED -> { }
        }
    }

    private fun onFileTransferred(t: TransferState, idx: Int, pid: Long) {
        if (t.direction == Direction.SENT) {
            t.completedBytes += t.files[idx].size
            t.fileProgress.remove(idx)
            t.fileStatus[idx] = TStatus.DONE
            recompute(t)
            closePayload(pid)
            t.inFlight--
            pump(t)
        } else {
            finalizeFile(t, idx, pid)
        }
    }

    private fun finalizeFile(t: TransferState, idx: Int, pid: Long) {
        val payload = payloadRefs[pid]
        val entry = t.files[idx]
        if (payload == null) { fail(t, "Couldn't save ${entry.name}.", notifyPeer = true); return }
        scope.launch {
            val r = withContext(Dispatchers.IO) {
                runCatching {
                    val pfd = payload.asFile()!!.asParcelFileDescriptor()
                    ParcelFileDescriptor.AutoCloseInputStream(pfd).use { Storage.saveReceived(app, entry.relPath, entry.mime, it) }
                }
            }
            try { payload.asFile()?.asJavaFile()?.delete() } catch (_: Exception) { }
            payloadRefs.remove(pid); payloadToFile.remove(pid); lastUpdate.remove(pid)
            val saved = r.getOrNull()
            if (saved == null) { fail(t, "Couldn't save ${entry.name}.", notifyPeer = true); return@launch }
            if (!t.isActive) { Storage.delete(app, saved.first); return@launch }
            t.savedUris[idx] = saved.first.toString()
            t.savedSha[idx] = saved.second
            if (entry.sha.isNotEmpty()) verifyFile(t, idx)
        }
    }

    private fun verifyFile(t: TransferState, idx: Int) {
        if (!t.isActive || t.fileStatus[idx] == TStatus.DONE) return
        val entry = t.files[idx]
        if (t.savedSha[idx] != entry.sha) {
            t.savedUris[idx]?.let { Storage.delete(app, Uri.parse(it)) }
            fail(t, "${entry.name} was damaged in transit. Please send it again.", notifyPeer = true)
            return
        }
        t.completedBytes += entry.size
        t.fileProgress.remove(idx)
        t.fileStatus[idx] = TStatus.DONE
        t.doneCount++
        recompute(t)
        if (t.doneCount == t.files.size) {
            t.done = t.total
            sendMsg(t.endpointId, JSONObject().put("t", "done").put("id", t.id).put("ok", true))
            endTransfer(t, TStatus.DONE, null)
        }
    }

    private fun recompute(t: TransferState) {
        t.done = (t.completedBytes + t.fileProgress.values.sum()).coerceAtMost(t.total)
        val tick = SystemClock.elapsedRealtime()
        if (tick - t.lastTick >= 700) {
            if (t.lastTick != 0L) {
                val inst = (t.done - t.lastBytes) * 1000 / (tick - t.lastTick)
                t.speed = if (t.speed == 0L) inst else (t.speed * 6 + inst * 4) / 10
            }
            t.lastTick = tick; t.lastBytes = t.done
            Notifier.updateProgress(t)
        }
    }

    // ---------------- ending transfers ----------------

    fun cancel(t: TransferState) {
        if (!t.isActive) return
        sendMsg(t.endpointId, JSONObject().put("t", "cancel").put("id", t.id).put("r", ""))
        cancelPayloadsOf(t)
        endTransfer(t, TStatus.CANCELLED, null)
    }

    private fun fail(t: TransferState, msg: String, notifyPeer: Boolean) {
        if (!t.isActive) return
        if (notifyPeer) try { sendMsg(t.endpointId, JSONObject().put("t", "cancel").put("id", t.id).put("r", msg)) } catch (_: Exception) { }
        cancelPayloadsOf(t)
        endTransfer(t, TStatus.FAILED, msg)
    }

    fun retry(t: TransferState) {
        if (t.direction != Direction.SENT || t.items.isEmpty()) { message = "Ask the sender to send the files again."; return }
        if (peers[t.endpointId]?.state == PeerState.CONNECTED) send(t.endpointId, t.items)
        else message = "Reconnect to ${t.peerName}, then send again."
    }

    private fun closePayload(pid: Long) {
        payloadRefs.remove(pid)?.let { try { it.asFile()?.asParcelFileDescriptor()?.close() } catch (_: Exception) { } }
        payloadToFile.remove(pid); lastUpdate.remove(pid)
    }

    private fun cancelPayloadsOf(t: TransferState) {
        payloadToFile.entries.filter { it.value.first == t.id }.map { it.key }.forEach { pid ->
            try { client.cancelPayload(pid) } catch (_: Exception) { }
            closePayload(pid)
        }
    }

    private fun endTransfer(t: TransferState, st: TStatus, err: String?) {
        t.status = st
        t.error = err
        t.endedAt = now()
        t.speed = 0
        saveRecord(t)
        refreshService()
        if (!hasActive() && Prefs.nearbyEnabled) Notifier.idle()
        when (st) {
            TStatus.DONE -> { lastCompleted = t; Notifier.finished(t, true) }
            TStatus.FAILED -> { message = err; Notifier.finished(t, false) }
            else -> { if (err != null) message = err }
        }
        if (!appVisible && !hasActive() && !Prefs.nearbyEnabled) stopRadios()
    }

    private fun saveRecord(t: TransferState) {
        val files = t.files.take(300).map { f ->
            val uri = if (t.direction == Direction.SENT) t.items.getOrNull(f.idx)?.uri?.toString() else t.savedUris[f.idx]
            RecordFile(f.name, f.size, f.mime, uri)
        }
        HistoryStore.upsert(
            TransferRecord(t.id, t.direction, t.peerName, t.status, t.startedAt, if (t.endedAt == 0L) now() else t.endedAt, t.total, t.files.size, t.error, files)
        )
    }

    fun refreshService() {
        val want = hasActive() || (Prefs.nearbyEnabled && permsOk)
        if (want) TransferService.start(app) else TransferService.stop(app)
        if (Prefs.nearbyEnabled && permsOk) Proximity.start() else Proximity.stop()
    }

}
