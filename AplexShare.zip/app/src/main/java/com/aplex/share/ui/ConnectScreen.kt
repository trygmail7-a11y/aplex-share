package com.aplex.share.ui

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.aplex.share.core.*
import com.aplex.share.data.*

@Composable
fun ConnectScreen(open: (Overlay) -> Unit, goFiles: () -> Unit) {
    val ctx = LocalContext.current
    val ensure = LocalEnsure.current
    val cs = MaterialTheme.colorScheme
    val sel = Selection.items.values.toList()
    val connected = NearbyEngine.peers.values.filter { it.state == PeerState.CONNECTED }
    val others = NearbyEngine.peers.values.filter { it.state != PeerState.CONNECTED }.sortedBy { it.name }

    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item {
            Text("Connect", style = MaterialTheme.typography.headlineSmall)
            Text("Find nearby phones that have Aplex Share open. No internet needed.", style = MaterialTheme.typography.bodyMedium, color = cs.onSurfaceVariant)
        }

        item {
            Card(colors = CardDefaults.cardColors(containerColor = cs.surface), border = BorderStroke(0.5.dp, cs.outlineVariant)) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text("Nearby sharing", fontWeight = FontWeight.Medium)
                            Text(if (Prefs.nearbyEnabled) "Discovery is on" else "Discovery is off", style = MaterialTheme.typography.bodySmall, color = cs.onSurfaceVariant)
                        }
                        Switch(checked = Prefs.nearbyEnabled, onCheckedChange = {
                            Prefs.nearbyEnabled = it; Prefs.save()
                            if (it) ensure(Permissions.nearby()) { NearbyEngine.settingsChanged() } else NearbyEngine.settingsChanged()
                        })
                    }
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("Visible to", style = MaterialTheme.typography.bodyMedium, modifier = Modifier.weight(1f))
                        FilterChip(selected = !Prefs.visibilityHidden, onClick = { Prefs.visibilityHidden = false; Prefs.save(); NearbyEngine.settingsChanged() }, label = { Text("Everyone") })
                        FilterChip(selected = Prefs.visibilityHidden, onClick = { Prefs.visibilityHidden = true; Prefs.save(); NearbyEngine.settingsChanged() }, label = { Text("Hidden") })
                    }
                }
            }
        }

        if (!NearbyEngine.permsOk) {
            item {
                Card(colors = CardDefaults.cardColors(containerColor = cs.primaryContainer)) {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("Allow nearby access", fontWeight = FontWeight.Medium, color = cs.onPrimaryContainer)
                        Text("Android needs your OK before this phone can find or be found by other phones.", style = MaterialTheme.typography.bodySmall, color = cs.onPrimaryContainer)
                        Button(onClick = { ensure(Permissions.nearby()) { } }) { Text("Allow") }
                    }
                }
            }
        }

        if (sel.isNotEmpty()) {
            item {
                Card(colors = CardDefaults.cardColors(containerColor = cs.primaryContainer)) {
                    Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Rounded.Send, null, tint = cs.primary)
                        Spacer(Modifier.width(10.dp))
                        Text("Sending ${sel.size} file(s) · ${formatSize(Selection.totalSize())}. Tap a device below.", color = cs.onPrimaryContainer, style = MaterialTheme.typography.bodyMedium, modifier = Modifier.weight(1f))
                    }
                }
            }
        }

        item {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(onClick = { ensure(Permissions.nearby()) { open(Overlay.MyQr) } }, Modifier.weight(1f)) {
                    Icon(Icons.Rounded.QrCode2, null, Modifier.size(18.dp)); Spacer(Modifier.width(6.dp)); Text("Show my QR", maxLines = 1)
                }
                OutlinedButton(onClick = { ensure(Permissions.nearby()) { QrScan.start(ctx) } }, Modifier.weight(1f)) {
                    Icon(Icons.Rounded.QrCodeScanner, null, Modifier.size(18.dp)); Spacer(Modifier.width(6.dp)); Text("Scan QR", maxLines = 1)
                }
            }
        }

        if (connected.isNotEmpty()) {
            item { Text("Connected", fontWeight = FontWeight.Medium) }
            items(connected, key = { "c" + it.id }) { p ->
                Card(colors = CardDefaults.cardColors(containerColor = cs.surface), border = BorderStroke(0.5.dp, cs.outlineVariant)) {
                    Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                        Avatar(p.avatar)
                        Spacer(Modifier.width(12.dp))
                        Column(Modifier.weight(1f)) {
                            Text(p.name, fontWeight = FontWeight.Medium)
                            Text("Connected", style = MaterialTheme.typography.bodySmall, color = androidx.compose.ui.graphics.Color(0xFF1D9E75))
                        }
                        if (sel.isNotEmpty()) Button(onClick = { NearbyEngine.send(p.id, sel) }) { Text("Send") }
                        else OutlinedButton(onClick = goFiles) { Text("Pick files") }
                        IconButton(onClick = { NearbyEngine.disconnect(p.id) }) { Icon(Icons.Rounded.Close, "Disconnect") }
                    }
                }
            }
        }

        item { Text("Nearby devices", fontWeight = FontWeight.Medium) }
        if (others.isEmpty()) {
            item {
                Column(Modifier.fillMaxWidth().padding(vertical = 12.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                    if (NearbyEngine.permsOk && Prefs.nearbyEnabled) {
                        Radar()
                        Text("Looking for devices…", style = MaterialTheme.typography.titleSmall)
                        Text("Open Aplex Share on the other phone and tap Receive.", style = MaterialTheme.typography.bodySmall, color = cs.onSurfaceVariant)
                    } else {
                        EmptyState(Icons.Rounded.WifiTethering, "Discovery is off", "Turn on nearby sharing and allow access to find devices.")
                    }
                }
            }
        } else {
            items(others, key = { it.id }) { p ->
                Card(
                    onClick = {
                        when (p.state) {
                            PeerState.CONNECTING -> { }
                            else -> {
                                if (sel.isNotEmpty()) NearbyEngine.queueSend(p.id, sel)
                                NearbyEngine.connect(p.id)
                            }
                        }
                    },
                    colors = CardDefaults.cardColors(containerColor = cs.surface), border = BorderStroke(0.5.dp, cs.outlineVariant)
                ) {
                    Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                        Avatar(p.avatar)
                        Spacer(Modifier.width(12.dp))
                        Column(Modifier.weight(1f)) {
                            Text(p.name, fontWeight = FontWeight.Medium)
                            Text(
                                when (p.state) {
                                    PeerState.CONNECTING -> "Waiting for approval…"
                                    PeerState.FAILED -> "Couldn't connect. Tap to retry"
                                    else -> "Tap to connect"
                                },
                                style = MaterialTheme.typography.bodySmall, color = cs.onSurfaceVariant
                            )
                        }
                        if (p.state == PeerState.CONNECTING) CircularProgressIndicator(Modifier.size(22.dp), strokeWidth = 2.dp)
                        else Icon(Icons.Rounded.PhoneAndroid, null, tint = cs.primary)
                    }
                }
            }
        }
    }
}
