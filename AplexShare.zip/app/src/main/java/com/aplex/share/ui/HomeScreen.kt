package com.aplex.share.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.aplex.share.core.*
import com.aplex.share.data.*

@Composable
fun HomeScreen(goTab: (Int) -> Unit, open: (Overlay) -> Unit, openCat: (Category) -> Unit) {
    val ctx = LocalContext.current
    val ensure = LocalEnsure.current
    val cs = MaterialTheme.colorScheme
    val connected = NearbyEngine.peers.values.count { it.state == PeerState.CONNECTED }
    val nearby = NearbyEngine.peers.values.filter { it.state != PeerState.CONNECTED }

    LazyColumn(
        Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(42.dp).clip(RoundedCornerShape(12.dp)).background(cs.primary), contentAlignment = Alignment.Center) {
                    Icon(Icons.Rounded.Share, null, tint = cs.onPrimary)
                }
                Spacer(Modifier.width(10.dp))
                Column(Modifier.weight(1f)) {
                    Text("Aplex Share", fontWeight = FontWeight.SemiBold, fontSize = 19.sp)
                    Text("Welcome, ${Prefs.deviceName}", style = MaterialTheme.typography.bodySmall, color = cs.onSurfaceVariant, maxLines = 1, overflow = TextOverflow.Ellipsis)
                }
                val (label, good) = when {
                    connected > 0 -> "$connected connected" to true
                    !NearbyEngine.permsOk -> "Setup needed" to false
                    !Prefs.nearbyEnabled -> "Nearby off" to false
                    else -> "Ready offline" to true
                }
                Text(
                    label, style = MaterialTheme.typography.labelSmall,
                    color = if (good) cs.primary else cs.onSurfaceVariant,
                    modifier = Modifier.clip(RoundedCornerShape(10.dp)).background(if (good) cs.primaryContainer else cs.surfaceVariant).padding(horizontal = 10.dp, vertical = 5.dp)
                )
                IconButton(onClick = { goTab(4) }) { Icon(Icons.Rounded.Settings, "Settings") }
            }
        }

        item {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                BigAction("Send", "Pick files", Icons.Rounded.ArrowUpward, true, Modifier.weight(1f)) {
                    openCat(Category.PHOTO)
                }
                BigAction("Receive", "Get files", Icons.Rounded.ArrowDownward, false, Modifier.weight(1f)) {
                    ensure(Permissions.nearby()) { open(Overlay.Receive) }
                }
            }
        }

        item {
            Card(Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = cs.surface), border = androidx.compose.foundation.BorderStroke(0.5.dp, cs.outlineVariant)) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Rounded.WifiTethering, null, tint = cs.primary)
                        Spacer(Modifier.width(8.dp))
                        Column(Modifier.weight(1f)) {
                            Text("Quick nearby share", fontWeight = FontWeight.Medium)
                            Text(
                                when {
                                    !NearbyEngine.permsOk -> "Allow nearby access to find devices"
                                    !Prefs.nearbyEnabled -> "Nearby sharing is off"
                                    NearbyEngine.discovering && nearby.isEmpty() -> "Searching for devices…"
                                    nearby.isNotEmpty() -> "${nearby.size} device(s) found"
                                    else -> "Works without internet"
                                },
                                style = MaterialTheme.typography.bodySmall, color = cs.onSurfaceVariant
                            )
                        }
                        if (!NearbyEngine.permsOk) Button(onClick = { ensure(Permissions.nearby()) { } }) { Text("Allow") }
                        else TextButton(onClick = { goTab(2) }) { Text("Open") }
                    }
                    if (nearby.isNotEmpty()) {
                        Row(horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                            nearby.take(4).forEach { p ->
                                Column(Modifier.width(64.dp).clickable { goTab(2) }, horizontalAlignment = Alignment.CenterHorizontally) {
                                    Avatar(p.avatar, 46.dp)
                                    Text(p.name, style = MaterialTheme.typography.labelSmall, maxLines = 1, overflow = TextOverflow.Ellipsis, color = cs.onSurfaceVariant)
                                }
                            }
                        }
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedButton(onClick = { ensure(Permissions.nearby()) { open(Overlay.MyQr) } }, Modifier.weight(1f)) {
                            Icon(Icons.Rounded.QrCode2, null, Modifier.size(18.dp)); Spacer(Modifier.width(6.dp)); Text("Show my QR", maxLines = 1)
                        }
                        OutlinedButton(onClick = { ensure(Permissions.nearby()) { QrScan.start(ctx) } }, Modifier.weight(1f)) {
                            Icon(Icons.Rounded.QrCodeScanner, null, Modifier.size(18.dp)); Spacer(Modifier.width(6.dp)); Text("Scan QR", maxLines = 1)
                        }
                    }
                }
            }
        }

        item {
            Text("Quick access", fontWeight = FontWeight.Medium, modifier = Modifier.padding(bottom = 8.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                QuickItem("Photos", Category.PHOTO, openCat)
                QuickItem("Videos", Category.VIDEO, openCat)
                QuickItem("Apps", Category.APK, openCat)
                QuickItem("Music", Category.MUSIC, openCat)
                QuickItem("Docs", Category.DOC, openCat)
            }
        }

        item { Text("Recent transfers", fontWeight = FontWeight.Medium) }
        val recent = HistoryStore.records.take(3)
        if (recent.isEmpty()) {
            item {
                EmptyState(Icons.Rounded.History, "No transfers yet", "Send or receive your first file and it will show up here.")
            }
        } else {
            items(recent.size) { i ->
                val r = recent[i]
                RecordRow(r) { goTab(3) }
            }
        }
    }
}

@Composable
private fun BigAction(title: String, sub: String, icon: ImageVector, filled: Boolean, modifier: Modifier, onClick: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    val bg = if (filled) cs.primary else cs.primaryContainer
    val fg = if (filled) cs.onPrimary else cs.onPrimaryContainer
    Column(
        modifier.clip(RoundedCornerShape(20.dp)).background(bg).clickable(onClick = onClick).padding(vertical = 22.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Icon(icon, null, tint = fg, modifier = Modifier.size(32.dp))
        Spacer(Modifier.height(6.dp))
        Text(title, color = fg, fontWeight = FontWeight.SemiBold, fontSize = 17.sp)
        Text(sub, color = fg.copy(alpha = 0.8f), style = MaterialTheme.typography.bodySmall)
    }
}

@Composable
private fun QuickItem(label: String, cat: Category, onClick: (Category) -> Unit) {
    Column(Modifier.width(60.dp).clickable { onClick(cat) }, horizontalAlignment = Alignment.CenterHorizontally) {
        CategoryBadge(cat, 48.dp)
        Spacer(Modifier.height(4.dp))
        Text(label, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

@Composable
fun RecordRow(r: TransferRecord, onClick: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    val first = r.files.firstOrNull()
    val cat = first?.let { categoryOf(it.name, it.mime) } ?: Category.OTHER
    Row(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).clickable(onClick = onClick).padding(vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        CategoryBadge(cat)
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            val title = (first?.name ?: "Files") + if (r.fileCount > 1) "  +${r.fileCount - 1} more" else ""
            Text(title, maxLines = 1, overflow = TextOverflow.Ellipsis)
            val dir = if (r.direction == Direction.SENT) "To" else "From"
            Text("$dir ${r.peer} · ${formatSize(r.totalBytes)} · ${formatDate(r.startedAt)}", style = MaterialTheme.typography.bodySmall, color = cs.onSurfaceVariant, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
        Spacer(Modifier.width(8.dp))
        StatusPill(r.status)
    }
}
