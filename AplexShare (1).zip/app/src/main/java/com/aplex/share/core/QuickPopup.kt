package com.aplex.share.core

import android.content.Context
import android.content.Intent
import android.content.res.Configuration
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.TextView
import com.aplex.share.MainActivity
import com.aplex.share.SendPickerActivity
import com.aplex.share.data.Prefs

/**
 * Pop-up card drawn over whatever app is on screen (needs "Display over other apps").
 * Every card has a close (X) button. Plain Android views work from a service without Compose setup.
 */
object QuickPopup {
    private var view: View? = null
    private var wm: WindowManager? = null
    private val handler = Handler(Looper.getMainLooper())
    private var timeout: Runnable? = null

    fun canShow(ctx: Context): Boolean = Settings.canDrawOverlays(ctx)

    fun dismiss() {
        timeout?.let { handler.removeCallbacks(it) }
        timeout = null
        view?.let { v -> try { wm?.removeView(v) } catch (_: Exception) { } }
        view = null
    }

    private fun dp(ctx: Context, v: Int) = (v * ctx.resources.displayMetrics.density).toInt()

    private fun isDark(ctx: Context) = when (Prefs.theme) {
        1 -> false
        2 -> true
        else -> (ctx.resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK) == Configuration.UI_MODE_NIGHT_YES
    }

    private fun show(
        ctx: Context, title: String, sub: String,
        buttons: List<Pair<String, () -> Unit>>, ms: Long,
        extra: Pair<String, () -> Unit>? = null
    ): Boolean {
        if (!canShow(ctx)) return false
        dismiss()
        val dark = isDark(ctx)
        val bg = if (dark) 0xFF111C33.toInt() else Color.WHITE
        val fg = if (dark) 0xFFE6EEF9.toInt() else 0xFF0F1B2D.toInt()
        val subColor = if (dark) 0xFFA8B7CE.toInt() else 0xFF55657A.toInt()
        val soft = if (dark) 0xFF1A2842.toInt() else 0xFFEAF1FA.toInt()

        val root = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(ctx, 20), dp(ctx, 14), dp(ctx, 14), dp(ctx, 16))
            background = GradientDrawable().apply { setColor(bg); cornerRadius = dp(ctx, 26).toFloat() }
            elevation = dp(ctx, 14).toFloat()
        }

        // header: brand + title on the left, close (X) on the right
        val head = LinearLayout(ctx).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.TOP }
        val titles = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL }
        titles.addView(TextView(ctx).apply {
            text = "Aplex Share"; setTextColor(0xFF378ADD.toInt()); textSize = 12f; typeface = Typeface.DEFAULT_BOLD
            setPadding(0, dp(ctx, 6), 0, 0)
        })
        titles.addView(TextView(ctx).apply {
            text = title; setTextColor(fg); textSize = 19f; typeface = Typeface.DEFAULT_BOLD
            setPadding(0, dp(ctx, 4), 0, 0)
        })
        head.addView(titles, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        head.addView(TextView(ctx).apply {
            text = "\u2715"; textSize = 20f; setTextColor(subColor); gravity = Gravity.CENTER
            setPadding(dp(ctx, 14), dp(ctx, 6), dp(ctx, 8), dp(ctx, 14))
            setOnClickListener { dismiss() }
        })
        root.addView(head)

        root.addView(TextView(ctx).apply {
            text = sub; setTextColor(subColor); textSize = 14f
            setPadding(0, dp(ctx, 2), dp(ctx, 6), dp(ctx, 16))
        })

        val row = LinearLayout(ctx).apply { orientation = LinearLayout.HORIZONTAL }
        buttons.forEachIndexed { i, (label, action) ->
            val primary = i == 0
            val b = TextView(ctx).apply {
                text = label; gravity = Gravity.CENTER; textSize = 15f; typeface = Typeface.DEFAULT_BOLD
                setTextColor(if (primary) Color.WHITE else fg)
                setPadding(dp(ctx, 8), dp(ctx, 14), dp(ctx, 8), dp(ctx, 14))
                background = GradientDrawable().apply {
                    cornerRadius = dp(ctx, 16).toFloat()
                    setColor(if (primary) 0xFF185FA5.toInt() else soft)
                }
                setOnClickListener { dismiss(); action() }
            }
            val lp = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
            if (i > 0) lp.marginStart = dp(ctx, 8)
            row.addView(b, lp)
        }
        val rowLp = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)
        rowLp.marginEnd = dp(ctx, 6)
        root.addView(row, rowLp)

        if (extra != null) {
            root.addView(TextView(ctx).apply {
                text = extra.first; gravity = Gravity.CENTER; textSize = 14f; typeface = Typeface.DEFAULT_BOLD
                setTextColor(0xFF378ADD.toInt())
                setPadding(0, dp(ctx, 14), dp(ctx, 6), dp(ctx, 2))
                setOnClickListener { dismiss(); extra.second() }
            })
        }

        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        )
        lp.gravity = Gravity.BOTTOM
        lp.horizontalMargin = 0.04f
        lp.y = dp(ctx, 28)

        return try {
            val w = ctx.getSystemService(WindowManager::class.java)
            w.addView(root, lp)
            wm = w
            view = root
            val r = Runnable { dismiss() }
            timeout = r
            handler.postDelayed(r, ms)
            true
        } catch (_: Exception) { false }
    }

    private fun startApp(ctx: Context, receive: Boolean) {
        ctx.startActivity(
            Intent(ctx, MainActivity::class.java)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP)
                .putExtra("receive", receive)
        )
    }

    /** Shown on both phones when they are almost touching. */
    fun showTouch(ctx: Context, tok: String, name: String): Boolean =
        show(
            ctx, "Connect to $name?", "The phones are touching. Connect to share files.",
            listOf(
                "Connect" to {
                    NearbyEngine.touchConnect(tok)
                    show(ctx, "Connecting to $name…", "Please wait a moment.", listOf("Cancel" to { NearbyEngine.touchDecline(tok) }), 25_000)
                    Unit
                },
                "Not now" to { NearbyEngine.touchDecline(tok) }
            ),
            30_000
        )

    fun showRequest(ctx: Context, r: ConnRequest): Boolean =
        show(
            ctx, "${r.name} wants to connect", "Code ${r.digits}. Make sure it matches on both phones.",
            listOf("Accept" to { NearbyEngine.acceptConnection() }, "Decline" to { NearbyEngine.rejectConnection() }),
            30_000
        )

    /** After connecting: Send / Receive, plus Open app and the X. */
    fun showChoice(ctx: Context, id: String, name: String): Boolean =
        show(
            ctx, "Connected to $name", "What do you want to do?",
            listOf(
                "Send files" to {
                    ctx.startActivity(
                        Intent(ctx, SendPickerActivity::class.java)
                            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                            .putExtra("peer", id)
                    )
                },
                "Receive files" to { startApp(ctx, true) }
            ),
            90_000,
            extra = "Open Aplex Share" to { startApp(ctx, false) }
        )

    fun showOffer(ctx: Context, t: TransferState): Boolean =
        show(
            ctx, "${t.peerName} wants to send files", "${t.files.size} file(s) · ${formatSize(t.total)}",
            listOf("Accept" to { NearbyEngine.acceptOffer(t) }, "Decline" to { NearbyEngine.declineOffer(t) }),
            60_000,
            extra = "Open Aplex Share" to { startApp(ctx, false) }
        )
}
