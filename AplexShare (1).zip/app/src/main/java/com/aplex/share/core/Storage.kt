package com.aplex.share.core

import android.content.ContentValues
import android.content.Context
import android.net.Uri
import android.provider.MediaStore
import java.io.IOException
import java.io.InputStream
import java.security.MessageDigest

object Storage {
    private fun hex(b: ByteArray) = b.joinToString("") { "%02x".format(it) }

    /** Streams [input] into Downloads/Aplex Share/<relPath> and returns the new Uri with its SHA-256. */
    fun saveReceived(ctx: Context, relPath: String, mime: String, input: InputStream): Pair<Uri, String> {
        val dir = relPath.substringBeforeLast('/', "")
        val name = relPath.substringAfterLast('/')
        val cv = ContentValues().apply {
            put(MediaStore.Downloads.DISPLAY_NAME, name)
            put(MediaStore.Downloads.MIME_TYPE, mime)
            put(MediaStore.Downloads.RELATIVE_PATH, "Download/Aplex Share" + if (dir.isEmpty()) "" else "/$dir")
            put(MediaStore.Downloads.IS_PENDING, 1)
        }
        val res = ctx.contentResolver
        val uri = res.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, cv) ?: throw IOException("Can't create file")
        val md = MessageDigest.getInstance("SHA-256")
        try {
            val out = res.openOutputStream(uri) ?: throw IOException("Can't write file")
            out.use {
                val buf = ByteArray(1024 * 1024)
                while (true) {
                    val n = input.read(buf)
                    if (n < 0) break
                    it.write(buf, 0, n)
                    md.update(buf, 0, n)
                }
            }
            res.update(uri, ContentValues().apply { put(MediaStore.Downloads.IS_PENDING, 0) }, null, null)
        } catch (e: Exception) {
            try { res.delete(uri, null, null) } catch (_: Exception) { }
            throw e
        }
        return uri to hex(md.digest())
    }

    fun sha256(ctx: Context, uri: Uri): String {
        val md = MessageDigest.getInstance("SHA-256")
        val stream = ctx.contentResolver.openInputStream(uri) ?: throw IOException("Can't read file")
        stream.use {
            val buf = ByteArray(1024 * 1024)
            while (true) {
                val n = it.read(buf)
                if (n < 0) break
                md.update(buf, 0, n)
            }
        }
        return hex(md.digest())
    }

    fun delete(ctx: Context, uri: Uri) {
        try { ctx.contentResolver.delete(uri, null, null) } catch (_: Exception) { }
    }

    /** Makes a path received from another device safe: no "..", no leading slash, no odd characters. */
    fun sanitize(path: String): String {
        val parts = path.replace('\\', '/').split('/')
            .map { seg -> seg.replace(Regex("[\\u0000-\\u001f:*?\"<>|]"), "_").trim().take(120) }
            .filter { it.isNotEmpty() && it != "." && it != ".." }
            .take(12)
        return if (parts.isEmpty()) "file" else parts.joinToString("/")
    }
}
