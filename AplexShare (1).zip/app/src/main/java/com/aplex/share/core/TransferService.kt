package com.aplex.share.core

import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.IBinder
import androidx.core.app.ServiceCompat
import androidx.core.content.ContextCompat

/** Keeps the process alive while files are moving, even if the screen turns off. */
class TransferService : Service() {
    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        try {
            ServiceCompat.startForeground(
                this, Notifier.FG_ID, Notifier.serviceNotification(this),
                ServiceInfo.FOREGROUND_SERVICE_TYPE_CONNECTED_DEVICE
            )
        } catch (_: Exception) {
            stopSelf()
        }
        NearbyEngine.onServiceStart(this)
        return START_STICKY
    }

    companion object {
        fun start(c: Context) {
            try { ContextCompat.startForegroundService(c, Intent(c, TransferService::class.java)) } catch (_: Exception) { }
        }
        fun stop(c: Context) {
            try { c.stopService(Intent(c, TransferService::class.java)) } catch (_: Exception) { }
        }
    }
}
