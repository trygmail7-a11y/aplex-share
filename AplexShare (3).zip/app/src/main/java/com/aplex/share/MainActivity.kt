package com.aplex.share

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.core.content.IntentCompat
import androidx.core.splashscreen.SplashScreen.Companion.installSplashScreen
import com.aplex.share.core.MediaRepo
import com.aplex.share.core.NearbyEngine
import com.aplex.share.data.Selection
import com.aplex.share.data.UiBus
import com.aplex.share.ui.AppRoot

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        installSplashScreen()
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        handleIntent(intent)
        setContent { AppRoot() }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        handleIntent(intent)
    }

    override fun onStart() {
        super.onStart()
        NearbyEngine.refreshPerms(this)
        NearbyEngine.onAppVisible(true)
        NearbyEngine.refreshService()
    }

    override fun onStop() {
        super.onStop()
        NearbyEngine.onAppVisible(false)
    }

    /** Files shared from other apps (Gallery, Files...) land in the selection. */
    private fun handleIntent(i: Intent?) {
        if (i == null) return
        if (i.hasExtra("tab")) UiBus.goTab = i.getIntExtra("tab", 0)
        if (i.getBooleanExtra("receive", false)) UiBus.openReceive = true
        val uris = ArrayList<Uri>()
        when (i.action) {
            Intent.ACTION_SEND ->
                IntentCompat.getParcelableExtra(i, Intent.EXTRA_STREAM, Uri::class.java)?.let { uris.add(it) }
            Intent.ACTION_SEND_MULTIPLE ->
                IntentCompat.getParcelableArrayListExtra(i, Intent.EXTRA_STREAM, Uri::class.java)?.let { uris.addAll(it) }
            else -> return
        }
        if (uris.isEmpty()) return
        val items = MediaRepo.fromUris(this, uris)
        if (items.isNotEmpty()) {
            Selection.addAll(items)
            UiBus.goSelected = true
        }
    }
}
