package com.aplex.share.ui

import android.bluetooth.BluetoothAdapter
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.Settings
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.aplex.share.core.NearbyEngine
import com.aplex.share.core.Radios
import com.aplex.share.data.Prefs
import kotlinx.coroutines.delay

data class RadioState(val bt: Boolean, val wifi: Boolean, val loc: Boolean) {
    val ok: Boolean get() = bt && wifi && loc
}

@Composable
fun rememberRadios(): State<RadioState> {
    val ctx = LocalContext.current
    return produceState(RadioState(Radios.bluetooth(ctx), Radios.wifi(ctx), Radios.location(ctx))) {
        while (true) {
            value = RadioState(Radios.bluetooth(ctx), Radios.wifi(ctx), Radios.location(ctx))
            delay(1000)
        }
    }
}

/**
 * Shows which of Bluetooth / Wi-Fi / Location are off and opens Android's own one-tap
 * prompts for them, one after another. Android does not let an app switch them on silently.
 */
@Composable
fun RadioSetupCard(autoRun: Boolean, showWhenOk: Boolean) {
    val ctx = LocalContext.current
    val cs = MaterialTheme.colorScheme
    val radios by rememberRadios()
    val latest by rememberUpdatedState(radios)
    var auto by remember { mutableStateOf(false) }
    var asked by remember { mutableStateOf(setOf<String>()) }
    var step by remember { mutableIntStateOf(0) }
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { step++ }

    fun launchFor(which: String) {
        try {
            launcher.launch(
                when (which) {
                    "bt" -> Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE)
                    "wifi" -> Intent(Settings.Panel.ACTION_WIFI)
                    else -> Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS)
                }
            )
        } catch (_: Exception) { step++ }
    }

    LaunchedEffect(autoRun) { if (autoRun) { asked = emptySet(); auto = true } }
    LaunchedEffect(auto, step) {
        if (!auto) return@LaunchedEffect
        val r = latest
        val next = when {
            !r.bt && "bt" !in asked -> "bt"
            !r.wifi && "wifi" !in asked -> "wifi"
            !r.loc && "loc" !in asked -> "loc"
            else -> null
        }
        if (next == null) auto = false else { asked = asked + next; launchFor(next) }
    }
    LaunchedEffect(radios.ok) {
        if (radios.ok) { NearbyEngine.refreshPerms(ctx); NearbyEngine.settingsChanged() }
    }

    if (radios.ok) {
        if (showWhenOk) {
            Row(
                Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(Icons.Rounded.CheckCircle, null, tint = Color(0xFF1D9E75), modifier = Modifier.size(18.dp))
                Spacer(Modifier.width(6.dp))
                Text("Bluetooth, Wi-Fi and Location are on", style = MaterialTheme.typography.bodySmall, color = cs.onSurfaceVariant)
            }
        }
        return
    }

    Card(colors = CardDefaults.cardColors(containerColor = cs.surface), border = BorderStroke(1.dp, Color(0xFFBA7517).copy(alpha = 0.5f))) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("Turn these on to connect", fontWeight = FontWeight.SemiBold)
            Text(
                "Both phones need them on. Wi-Fi also makes transfers much faster.",
                style = MaterialTheme.typography.bodySmall, color = cs.onSurfaceVariant
            )
            RadioRow("Bluetooth", Icons.Rounded.Bluetooth, radios.bt) { launchFor("bt") }
            RadioRow("Wi-Fi", Icons.Rounded.Wifi, radios.wifi) { launchFor("wifi") }
            RadioRow("Location", Icons.Rounded.LocationOn, radios.loc) { launchFor("loc") }
            Button(onClick = { asked = emptySet(); auto = true; step++ }, Modifier.fillMaxWidth()) { Text("Turn everything on") }
        }
    }
}

@Composable
private fun RadioRow(label: String, icon: ImageVector, on: Boolean, onTurnOn: () -> Unit) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Icon(icon, null, tint = if (on) Color(0xFF1D9E75) else Color(0xFFBA7517))
        Spacer(Modifier.width(10.dp))
        Text(label, Modifier.weight(1f))
        if (on) Text("On", color = Color(0xFF1D9E75), style = MaterialTheme.typography.labelMedium)
        else TextButton(onClick = onTurnOn) { Text("Turn on") }
    }
}

/** Asks for "Display over other apps" so pop-ups can appear even when Aplex Share is closed. */
@Composable
fun OverlayPermCard() {
    val ctx = LocalContext.current
    val cs = MaterialTheme.colorScheme
    val ok by produceState(Settings.canDrawOverlays(ctx)) {
        while (true) { value = Settings.canDrawOverlays(ctx); delay(1000) }
    }
    if (ok || !Prefs.nearbyEnabled) return
    Card(colors = CardDefaults.cardColors(containerColor = cs.primaryContainer)) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("Allow pop-ups over other apps", fontWeight = FontWeight.SemiBold, color = cs.onPrimaryContainer)
            Text(
                "This lets \"Connect to this device\", Send and Receive pop-ups appear on your screen even when Aplex Share is closed.",
                style = MaterialTheme.typography.bodySmall, color = cs.onPrimaryContainer
            )
            Button(onClick = {
                try {
                    ctx.startActivity(
                        Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + ctx.packageName))
                            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    )
                } catch (_: Exception) { }
            }) { Text("Allow") }
        }
    }
}

fun askOverlayPermission(ctx: Context) {
    try {
        ctx.startActivity(
            Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + ctx.packageName))
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        )
    } catch (_: Exception) { }
}
