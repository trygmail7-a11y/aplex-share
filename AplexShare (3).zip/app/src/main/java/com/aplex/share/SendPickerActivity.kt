package com.aplex.share

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import com.aplex.share.core.MediaRepo
import com.aplex.share.core.NearbyEngine
import com.aplex.share.core.PeerState
import com.aplex.share.core.toast

/** Invisible activity: opens the system file picker and sends what you choose to the connected phone. */
class SendPickerActivity : ComponentActivity() {
    private val picker = registerForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris ->
        val peer = intent.getStringExtra("peer")
        if (uris.isNotEmpty() && peer != null) {
            val items = MediaRepo.fromUris(this, uris)
            if (items.isEmpty()) toast(this, "Couldn't read those files")
            else if (NearbyEngine.peers[peer]?.state == PeerState.CONNECTED) NearbyEngine.send(peer, items)
            else toast(this, "Not connected anymore. Connect again.")
        }
        finish()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        picker.launch(arrayOf("*/*"))
    }
}
