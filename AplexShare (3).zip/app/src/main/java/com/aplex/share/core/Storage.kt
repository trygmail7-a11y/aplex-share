package com.aplex.share.core

import android.content.ContentValues
import android.content.Context
import android.net.Uri
import android.os.ParcelFileDescriptor
import android.provider.MediaStore
import java.io.IOException
import java.nio.ByteBuffer
import java.security.MessageDigest

object Storage {
    private fun hex(b: ByteArray) = b.joinToString("") { "%02x".format(it) }

    /**
     * Copies the received payload file into Downloads/Aplex Share/<relPath> using a kernel-level
     * channel copy (much faster than a read/write loop). Returns the new Uri and the byte count.
     * [src] is closed here.
     */
    fun saveReceived(ctx: Context, relPath: String, mime: String, src: ParcelFileDescriptor): Pair<Uri, Long> {
        val dir = relPath.substringBeforeLast('/', "")
        val name = relPath.substringAfterLast('/')
        val cv = ContentValues().apply {
            put(MediaStore.Downloads.DISPLAY_NAME, name)
            put(MediaStore.Downloads.MIME_TYPE, mime)
            put(MediaStore.Downloads.RELATIVE_PATH, "Download/Aplex Share" + if (dir.isEmpty()) "" else "/$dir")
            put(MediaStore.Downloads.IS_PENDING, 1)
        }
        val res = ctx.contentResolver
        val uri = res.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, cv)
        if (uri == null) { try { src.close() } catch (_: Exception) { }; throw IOException("Can't create file") }
        var copied = 0L
        try {
            val outPfd = res.openFileDescriptor(uri, "w") ?: throw IOException("Can't write file")
            ParcelFileDescriptor.AutoCloseInputStream(src).channel.use { inCh ->
                ParcelFileDescriptor.AutoCloseOutputStream(outPfd).channel.use { outCh ->
                    val size = inCh.size()
                    var pos = 0L
                    while (pos < size) {
                        val n = inCh.transferTo(pos, size - pos, outCh)
                        if (n <= 0) break
                        pos += n
                    }
                    if (pos < size) { // rare: fall back to a plain buffered copy for the rest
                        val bb = ByteBuffer.allocateDirect(1 shl 20)
                        inCh.position(pos)
                        while (true) {
                            bb.clear()
                            val r = inCh.read(bb)
                            if (r < 0) break
                            bb.flip()
                            while (bb.hasRemaining()) outCh.write(bb)
                            pos += r
                        }
                    }
                    copied = pos
                }
            }
            res.update(uri, ContentValues().apply { put(MediaStore.Downloads.IS_PENDING, 0) }, null, null)
        } catch (e: Exception) {
            try { src.close() } catch (_: Exception) { }
            try { res.delete(uri, null, null) } catch (_: Exception) { }
            throw e
        }
        return uri to copied
    }

    fun sha256(ctx: Context, uri: Uri): String {
        val md = MessageDigest.getInstance("SHA-256")
        val stream = ctx.contentResolver.openInputStream(uri) ?: throw IOException("Can't read file")
        stream.use {
            val buf = ByteArray(1024 * 1024)
            while (true) {
                val n = it.read(buf)
                if (n < 0) break
                md.update(buf, 0, n)
            }
        }
        return hex(md.digest())
    }

    fun delete(ctx: Context, uri: Uri) {
        try { ctx.contentResolver.delete(uri, null, null) } catch (_: Exception) { }
    }

    /** Makes a path received from another device safe: no "..", no leading slash, no odd characters. */
    fun sanitize(path: String): String {
        val parts = path.replace('\\', '/').split('/')
            .map { seg -> seg.replace(Regex("[\\u0000-\\u001f:*?\"<>|]"), "_").trim().take(120) }
            .filter { it.isNotEmpty() && it != "." && it != ".." }
            .take(12)
        return if (parts.isEmpty()) "file" else parts.joinToString("/")
    }
}
