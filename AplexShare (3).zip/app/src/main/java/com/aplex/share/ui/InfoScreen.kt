package com.aplex.share.ui

import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.aplex.share.core.toast

/** Put your support e-mail here. Leave it empty to show only the website. */
private const val CONTACT_EMAIL = "aplexstudio.in@gmail.com"
private const val WEBSITE = "https://privacyshareapp.blogspot.com"

@Composable
fun InfoScreen(kind: Int, onClose: () -> Unit) {
    val ctx = LocalContext.current
    val cs = MaterialTheme.colorScheme
    val title = when (kind) { 0 -> "Terms & Conditions"; 1 -> "About Us"; else -> "Contact Us" }

    Column(Modifier.fillMaxSize()) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onClose) { Icon(Icons.Rounded.Close, "Close") }
            Text(title, style = MaterialTheme.typography.titleLarge)
        }
        Column(
            Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(horizontal = 20.dp, vertical = 8.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            when (kind) {
                0 -> {
                    Para("1. Using Aplex Share", "Aplex Share lets you send and receive files between nearby phones. You are responsible for the files you send and receive.")
                    Para("2. Your content", "Only share content you have the right to share. Do not use the app for anything illegal, harmful, or that infringes someone else's rights.")
                    Para("3. Approval and safety", "Incoming files need your approval. Accept files only from people you trust. Files such as APKs from unknown sources can be harmful. The app never installs received apps automatically.")
                    Para("4. No warranty", "The app is provided \"as is\". Transfer speed depends on your phones and surroundings. Transfers can fail, and we are not responsible for lost or damaged data.")
                    Para("5. Your data", "There is no account. Files go directly between the two phones. See the Privacy Policy for details.")
                    Para("6. Changes", "These terms may change with app updates. Continuing to use the app means you accept the updated terms.")
                }
                1 -> {
                    Para("Aplex Share", "A fast file-sharing app for Android that works without internet, without an account and without ads.")
                    Para("What it does", "Touch two phones together or pick a nearby device, then send photos, videos, music, apps, documents and whole folders directly to the other phone.")
                    Para("Private by design", "Files travel straight between the phones over an encrypted link. Nothing is uploaded to a server.")
                    Text("Version 1.0.0", style = MaterialTheme.typography.bodySmall, color = cs.onSurfaceVariant)
                }
                else -> {
                    Para("We'd love to hear from you", "Questions, feedback or a bug to report? Visit our website for help and our privacy policy.")
                    Button(onClick = {
                        try { ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(WEBSITE)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
                        catch (_: Exception) { toast(ctx, "No browser found") }
                    }) { Text("Open website") }
                    if (CONTACT_EMAIL.isNotBlank()) {
                        OutlinedButton(onClick = {
                            try {
                                ctx.startActivity(
                                    Intent(Intent.ACTION_SENDTO, Uri.parse("mailto:$CONTACT_EMAIL"))
                                        .putExtra(Intent.EXTRA_SUBJECT, "Aplex Share feedback")
                                        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                                )
                            } catch (_: Exception) { toast(ctx, "No e-mail app found") }
                        }) { Text("Email us") }
                    }
                }
            }
        }
    }
}

@Composable
private fun Para(head: String, body: String) {
    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
        Text(head, fontWeight = FontWeight.SemiBold)
        Text(body, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}
