# --- Release hardening (R8): shrink + obfuscate + optimise DEX ---
-dontwarn com.google.android.gms.**

# Move every renamed class into one package and make names as short as possible.
-repackageclasses 'a'
-allowaccessmodification
-overloadaggressively

# Keep just enough for readable crash reports in Play Console (upload mapping.txt there).
-keepattributes SourceFile,LineNumberTable
-renamesourcefileattribute SourceFile
