package com.aplex.share.ui

import android.os.Environment
import android.os.StatFs
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.aplex.share.core.*
import com.aplex.share.data.*

@Composable
fun ProfileScreen() {
    val ctx = LocalContext.current
    val cs = MaterialTheme.colorScheme
    var name by remember { mutableStateOf(Prefs.deviceName) }
    val (total, free) = remember {
        try { val s = StatFs(Environment.getExternalStorageDirectory().path); s.totalBytes to s.availableBytes } catch (_: Exception) { 1L to 0L }
    }

    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
        item {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Avatar(Prefs.avatar, 64.dp)
                Spacer(Modifier.width(14.dp))
                Column {
                    Text(Prefs.deviceName, style = MaterialTheme.typography.titleLarge)
                    Text("This is how other phones see you", style = MaterialTheme.typography.bodySmall, color = cs.onSurfaceVariant)
                }
            }
        }
        item {
            Section("Device name") {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(name, { name = it.take(30) }, singleLine = true, modifier = Modifier.weight(1f))
                    Button(onClick = {
                        Prefs.deviceName = name.trim().ifBlank { Prefs.defaultName() }
                        name = Prefs.deviceName
                        Prefs.save(); NearbyEngine.settingsChanged(); toast(ctx, "Saved")
                    }) { Text("Save") }
                }
            }
        }
        item {
            Section("Avatar") {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    for (row in 0..1) {
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
                            for (k in 0..3) {
                                val i = row * 4 + k
                                Box(
                                    Modifier.clickable { Prefs.avatar = i; Prefs.save(); NearbyEngine.settingsChanged() }
                                        .then(if (Prefs.avatar == i) Modifier.border(2.dp, cs.primary, CircleShape).padding(3.dp) else Modifier.padding(5.dp))
                                ) { Avatar(i, 48.dp) }
                            }
                        }
                    }
                }
            }
        }
        item {
            Section("Appearance") {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf("System", "Light", "Dark").forEachIndexed { i, s ->
                        FilterChip(selected = Prefs.theme == i, onClick = { Prefs.theme = i; Prefs.save() }, label = { Text(s) })
                    }
                }
            }
        }
        item {
            Section("Storage") {
                val used = (total - free).coerceAtLeast(0)
                LinearProgressIndicator(progress = { used.toFloat() / total.coerceAtLeast(1) }, Modifier.fillMaxWidth())
                Text("${formatSize(used)} used · ${formatSize(free)} free of ${formatSize(total)}", style = MaterialTheme.typography.bodySmall, color = cs.onSurfaceVariant)
                OutlinedButton(onClick = { openReceivedFolder(ctx) }) {
                    Icon(Icons.Rounded.FolderOpen, null, Modifier.size(18.dp)); Spacer(Modifier.width(6.dp)); Text("Open received files")
                }
                Text("Received files are saved in Downloads/Aplex Share.", style = MaterialTheme.typography.bodySmall, color = cs.onSurfaceVariant)
            }
        }
        item {
            Section("Privacy") {
                Text(
                    "Files travel directly between the two phones. Nothing is uploaded, there is no account, and every incoming transfer needs your approval. Received APK files are never installed automatically.",
                    style = MaterialTheme.typography.bodyMedium, color = cs.onSurfaceVariant
                )
            }
        }
        item { Text("Aplex Share 1.0.0", style = MaterialTheme.typography.bodySmall, color = cs.onSurfaceVariant, modifier = Modifier.padding(bottom = 8.dp)) }
    }
}

@Composable
private fun Section(title: String, content: @Composable ColumnScope.() -> Unit) {
    Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface), border = BorderStroke(0.5.dp, MaterialTheme.colorScheme.outlineVariant)) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text(title, fontWeight = FontWeight.Medium)
            content()
        }
    }
}
