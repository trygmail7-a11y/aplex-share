package com.aplex.share

import android.app.Application
import com.aplex.share.core.NearbyEngine
import com.aplex.share.core.Notifier
import com.aplex.share.data.HistoryStore
import com.aplex.share.data.Prefs

class AplexApp : Application() {
    override fun onCreate() {
        super.onCreate()
        Prefs.init(this)
        HistoryStore.init(this)
        Notifier.init(this)
        NearbyEngine.init(this)
    }
}
