package com.aplex.share.data

import android.net.Uri

/** OTHER doubles as the "Selected" tab marker inside the Files screen. */
enum class Category { PHOTO, VIDEO, MUSIC, DOC, APK, ZIP, OTHER }

enum class Direction { SENT, RECEIVED }

enum class TStatus { PREPARING, WAITING, ACTIVE, DONE, FAILED, CANCELLED, DECLINED }

data class SendItem(
    val uri: Uri,
    val name: String,
    val size: Long,
    val mime: String,
    val relPath: String,
    val category: Category,
    val dateMs: Long = 0L
) {
    val key: String get() = uri.toString()
}

class FileEntry(val idx: Int, val name: String, val relPath: String, val size: Long, val mime: String) {
    var sha: String = ""
}

data class RecordFile(val name: String, val size: Long, val mime: String, val uri: String?)

data class TransferRecord(
    val id: String,
    val direction: Direction,
    val peer: String,
    val status: TStatus,
    val startedAt: Long,
    val endedAt: Long,
    val totalBytes: Long,
    val fileCount: Int,
    val error: String?,
    val files: List<RecordFile>
)
