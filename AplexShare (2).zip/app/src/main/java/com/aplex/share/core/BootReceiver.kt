package com.aplex.share.core

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import com.aplex.share.data.Prefs

/** Turns Quick Share back on after the phone restarts (if it was on). */
class BootReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        if (i.action != Intent.ACTION_BOOT_COMPLETED) return
        try {
            if (Prefs.nearbyEnabled) {
                NearbyEngine.refreshPerms(c)
                if (NearbyEngine.permsOk) NearbyEngine.backgroundStart()
            }
        } catch (_: Exception) { }
    }
}
