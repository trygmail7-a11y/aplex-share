package com.aplex.share.core

import android.app.NotificationManager
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

/** Handles the Accept / Decline / Connect buttons on notifications. */
class ActionReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        val id = i.getStringExtra("id") ?: return
        when (i.action) {
            Notifier.ACT_ACCEPT_CONN -> NearbyEngine.acceptConnection()
            Notifier.ACT_REJECT_CONN -> NearbyEngine.rejectConnection()
            Notifier.ACT_ACCEPT_OFFER -> NearbyEngine.acceptOfferById(id)
            Notifier.ACT_DECLINE_OFFER -> NearbyEngine.declineOfferById(id)
            Notifier.ACT_CONNECT -> NearbyEngine.connectById(id)
        }
        try { c.getSystemService(NotificationManager::class.java).cancel(i.getIntExtra("nid", 0)) } catch (_: Exception) { }
    }
}
