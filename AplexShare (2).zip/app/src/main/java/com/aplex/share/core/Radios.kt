package com.aplex.share.core

import android.bluetooth.BluetoothManager
import android.content.Context
import android.location.LocationManager
import android.net.wifi.WifiManager
import androidx.core.location.LocationManagerCompat

/** Nearby sharing needs Bluetooth, Wi-Fi and Location switched on. Android won't let apps flip them silently. */
object Radios {
    fun bluetooth(ctx: Context): Boolean = try {
        ctx.getSystemService(BluetoothManager::class.java)?.adapter?.isEnabled == true
    } catch (_: Exception) { false }

    fun wifi(ctx: Context): Boolean = try {
        ctx.applicationContext.getSystemService(WifiManager::class.java)?.isWifiEnabled == true
    } catch (_: Exception) { false }

    fun location(ctx: Context): Boolean = try {
        val lm = ctx.getSystemService(LocationManager::class.java)
        lm != null && LocationManagerCompat.isLocationEnabled(lm)
    } catch (_: Exception) { false }
}
