package com.aplex.share.ui

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.aplex.share.core.*
import com.aplex.share.data.*

@Composable
fun ActivityScreen(open: (Overlay) -> Unit) {
    val ctx = LocalContext.current
    val cs = MaterialTheme.colorScheme
    var tab by remember { mutableIntStateOf(0) }
    var detail by remember { mutableStateOf<TransferRecord?>(null) }
    var confirm by remember { mutableStateOf(false) }

    val all = HistoryStore.records.toList()
    val list = when (tab) {
        1 -> all.filter { it.direction == Direction.SENT }
        2 -> all.filter { it.direction == Direction.RECEIVED }
        3 -> all.filter { it.status != TStatus.DONE }
        else -> all
    }
    val active = NearbyEngine.transfers.values.filter { it.isActive }

    Column(Modifier.fillMaxSize()) {
        Row(Modifier.padding(start = 16.dp, end = 8.dp, top = 12.dp), verticalAlignment = Alignment.CenterVertically) {
            Text("Activity", style = MaterialTheme.typography.headlineSmall, modifier = Modifier.weight(1f))
            if (all.isNotEmpty()) TextButton(onClick = { confirm = true }) { Text("Clear history") }
        }
        TabRow(selectedTabIndex = tab, containerColor = cs.background) {
            listOf("All", "Sent", "Received", "Failed").forEachIndexed { i, s ->
                Tab(selected = tab == i, onClick = { tab = i }, text = { Text(s) })
            }
        }
        LazyColumn(Modifier.weight(1f), contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            if (active.isNotEmpty() && tab == 0) {
                items(active, key = { "a" + it.id }) { t ->
                    Card(onClick = { open(Overlay.Progress(t.id)) }, colors = CardDefaults.cardColors(containerColor = cs.primaryContainer)) {
                        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            Text(
                                (if (t.direction == Direction.SENT) "Sending to " else "Receiving from ") + t.peerName,
                                fontWeight = FontWeight.Medium, color = cs.onPrimaryContainer
                            )
                            LinearProgressIndicator(progress = { if (t.total > 0) t.done.toFloat() / t.total else 0f }, Modifier.fillMaxWidth())
                            Text("${formatSize(t.done)} of ${formatSize(t.total)}", style = MaterialTheme.typography.bodySmall, color = cs.onPrimaryContainer)
                        }
                    }
                }
            }
            if (list.isEmpty() && active.isEmpty()) {
                item { EmptyState(Icons.Rounded.History, "Nothing here yet", "Your sent and received files will be listed here.", Modifier.padding(top = 40.dp)) }
            }
            items(list, key = { it.id }) { r -> RecordRow(r) { detail = r } }
        }
    }

    if (confirm) {
        AlertDialog(
            onDismissRequest = { confirm = false },
            title = { Text("Clear history?") },
            text = { Text("This removes the list only. Your received files stay in Downloads/Aplex Share.") },
            confirmButton = { TextButton(onClick = { HistoryStore.clear(); confirm = false }) { Text("Clear") } },
            dismissButton = { TextButton(onClick = { confirm = false }) { Text("Cancel") } }
        )
    }

    detail?.let { r ->
        AlertDialog(
            onDismissRequest = { detail = null },
            title = { Text(if (r.direction == Direction.SENT) "Sent to ${r.peer}" else "Received from ${r.peer}") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Row { StatusPill(r.status) }
                    Text("${r.fileCount} file(s) · ${formatSize(r.totalBytes)}", style = MaterialTheme.typography.bodyMedium)
                    Text("${formatDate(r.startedAt)} · took ${formatDuration(r.endedAt - r.startedAt)}", style = MaterialTheme.typography.bodySmall, color = cs.onSurfaceVariant)
                    r.error?.let { Text(it, style = MaterialTheme.typography.bodySmall, color = statusColor(TStatus.FAILED)) }
                    LazyColumn(Modifier.heightIn(max = 260.dp)) {
                        items(r.files) { f ->
                            Row(Modifier.fillMaxWidth().padding(vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                                Column(Modifier.weight(1f)) {
                                    Text(f.name, maxLines = 1, overflow = TextOverflow.Ellipsis, style = MaterialTheme.typography.bodyMedium)
                                    Text("${typeLabel(f.name)} · ${formatSize(f.size)}", style = MaterialTheme.typography.bodySmall, color = cs.onSurfaceVariant)
                                }
                                if (r.status == TStatus.DONE && f.uri != null) {
                                    TextButton(onClick = { openFile(ctx, f.uri, f.mime) }) { Text("Open") }
                                    if (r.direction == Direction.RECEIVED) IconButton(onClick = { shareFile(ctx, f.uri, f.mime) }) { Icon(Icons.Rounded.Share, "Share") }
                                }
                            }
                        }
                    }
                }
            },
            confirmButton = { TextButton(onClick = { detail = null }) { Text("Close") } },
            dismissButton = { if (r.direction == Direction.RECEIVED) TextButton(onClick = { openReceivedFolder(ctx) }) { Text("View folder") } }
        )
    }
}
