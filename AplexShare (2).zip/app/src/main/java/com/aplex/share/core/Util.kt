package com.aplex.share.core

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.util.Size
import android.webkit.MimeTypeMap
import android.widget.Toast
import androidx.compose.runtime.Composable
import androidx.compose.runtime.produceState
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.LocalContext
import com.aplex.share.data.Category
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

fun formatSize(bytes: Long): String {
    if (bytes < 1024) return "$bytes B"
    val units = arrayOf("KB", "MB", "GB", "TB")
    var v = bytes.toDouble()
    var i = -1
    while (v >= 1024 && i < units.lastIndex) { v /= 1024; i++ }
    return String.format(Locale.US, if (v >= 100) "%.0f %s" else "%.1f %s", v, units[i])
}

fun formatSpeed(bps: Long): String = formatSize(bps) + "/s"

fun formatDuration(ms: Long): String {
    val s = (ms / 1000).coerceAtLeast(0)
    return when {
        s >= 3600 -> String.format(Locale.US, "%dh %02dm", s / 3600, (s % 3600) / 60)
        s >= 60 -> String.format(Locale.US, "%dm %02ds", s / 60, s % 60)
        else -> "${s}s"
    }
}

fun formatDate(ms: Long): String = SimpleDateFormat("d MMM, h:mm a", Locale.getDefault()).format(Date(ms))

fun typeLabel(name: String): String {
    val e = name.substringAfterLast('.', "")
    return if (e.isEmpty() || e.length > 5) "FILE" else e.uppercase(Locale.ROOT)
}

fun categoryOf(name: String, mime: String): Category {
    val n = name.lowercase(Locale.ROOT)
    return when {
        mime.startsWith("image/") -> Category.PHOTO
        mime.startsWith("video/") -> Category.VIDEO
        mime.startsWith("audio/") -> Category.MUSIC
        n.endsWith(".apk") || n.endsWith(".apks") || n.endsWith(".xapk") -> Category.APK
        n.endsWith(".zip") || n.endsWith(".rar") || n.endsWith(".7z") || n.endsWith(".tar") || n.endsWith(".gz") -> Category.ZIP
        mime.startsWith("text/") || mime == "application/pdf" || mime.contains("word") ||
            mime.contains("sheet") || mime.contains("excel") || mime.contains("presentation") ||
            mime.contains("powerpoint") || n.endsWith(".txt") || n.endsWith(".pdf") -> Category.DOC
        else -> Category.OTHER
    }
}

fun categoryLabel(c: Category): String = when (c) {
    Category.PHOTO -> "photos"
    Category.VIDEO -> "videos"
    Category.MUSIC -> "music"
    Category.DOC -> "documents"
    Category.APK -> "apps"
    Category.ZIP -> "archives"
    Category.OTHER -> "other files"
}

fun guessMime(name: String): String {
    val ext = name.substringAfterLast('.', "").lowercase(Locale.ROOT)
    return MimeTypeMap.getSingleton().getMimeTypeFromExtension(ext) ?: "application/octet-stream"
}

fun toast(ctx: Context, msg: String) = Toast.makeText(ctx, msg, Toast.LENGTH_SHORT).show()

fun openFile(ctx: Context, uri: String, mime: String) {
    try {
        ctx.startActivity(
            Intent(Intent.ACTION_VIEW).setDataAndType(Uri.parse(uri), mime)
                .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
        )
    } catch (_: Exception) {
        toast(ctx, "No app can open this file")
    }
}

fun shareFile(ctx: Context, uri: String, mime: String) {
    try {
        val send = Intent(Intent.ACTION_SEND).setType(mime)
            .putExtra(Intent.EXTRA_STREAM, Uri.parse(uri))
            .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        ctx.startActivity(Intent.createChooser(send, "Share").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    } catch (_: Exception) {
        toast(ctx, "Couldn't share this file")
    }
}

/** Opens the system Downloads app, where the "Aplex Share" folder lives. */
fun openReceivedFolder(ctx: Context) {
    try {
        ctx.startActivity(Intent(android.app.DownloadManager.ACTION_VIEW_DOWNLOADS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    } catch (_: Exception) {
        toast(ctx, "Open Files > Downloads > Aplex Share")
    }
}

@Composable
fun rememberThumb(uri: Uri, enabled: Boolean): ImageBitmap? {
    val ctx = LocalContext.current
    return produceState<ImageBitmap?>(null, uri, enabled) {
        if (enabled) {
            value = withContext(Dispatchers.IO) {
                try { ctx.contentResolver.loadThumbnail(uri, Size(160, 160), null).asImageBitmap() } catch (_: Exception) { null }
            }
        }
    }.value
}
