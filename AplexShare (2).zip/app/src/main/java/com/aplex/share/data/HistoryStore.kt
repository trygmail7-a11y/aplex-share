package com.aplex.share.data

import android.content.Context
import androidx.compose.runtime.mutableStateListOf
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

object HistoryStore {
    private lateinit var file: File
    val records = mutableStateListOf<TransferRecord>()

    fun init(ctx: Context) {
        file = File(ctx.filesDir, "history.json")
        try {
            if (file.exists()) {
                val arr = JSONArray(file.readText())
                for (i in 0 until arr.length()) records.add(fromJson(arr.getJSONObject(i)))
            }
        } catch (_: Exception) { /* corrupt history is simply dropped */ }
    }

    fun upsert(r: TransferRecord) {
        val i = records.indexOfFirst { it.id == r.id }
        if (i >= 0) records[i] = r else records.add(0, r)
        while (records.size > 500) records.removeAt(records.size - 1)
        persist()
    }

    fun clear() { records.clear(); persist() }

    private fun persist() {
        try {
            val arr = JSONArray()
            records.forEach { arr.put(toJson(it)) }
            file.writeText(arr.toString())
        } catch (_: Exception) { }
    }

    private fun toJson(r: TransferRecord) = JSONObject().apply {
        put("id", r.id); put("dir", r.direction.name); put("peer", r.peer); put("st", r.status.name)
        put("s", r.startedAt); put("e", r.endedAt); put("tb", r.totalBytes); put("fc", r.fileCount)
        put("err", r.error ?: "")
        put("files", JSONArray().apply {
            r.files.forEach { f ->
                put(JSONObject().put("n", f.name).put("z", f.size).put("m", f.mime).put("u", f.uri ?: ""))
            }
        })
    }

    private fun fromJson(o: JSONObject): TransferRecord {
        val fa = o.getJSONArray("files")
        val files = (0 until fa.length()).map {
            val f = fa.getJSONObject(it)
            RecordFile(f.getString("n"), f.getLong("z"), f.getString("m"), f.getString("u").ifEmpty { null })
        }
        return TransferRecord(
            o.getString("id"), Direction.valueOf(o.getString("dir")), o.getString("peer"),
            TStatus.valueOf(o.getString("st")), o.getLong("s"), o.getLong("e"), o.getLong("tb"),
            o.getInt("fc"), o.optString("err").ifEmpty { null }, files
        )
    }
}
