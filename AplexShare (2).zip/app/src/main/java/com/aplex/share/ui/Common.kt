package com.aplex.share.ui

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.aplex.share.data.Category
import com.aplex.share.data.TStatus

/** (permissions, actionOnceGranted) */
val LocalEnsure = staticCompositionLocalOf<(Array<String>, () -> Unit) -> Unit> { { _, a -> a() } }

sealed interface Overlay {
    data object Receive : Overlay
    data object MyQr : Overlay
    data class Progress(val id: String) : Overlay
    data class Success(val id: String) : Overlay
}

val AvatarIcons: List<ImageVector> = listOf(
    Icons.Rounded.Person, Icons.Rounded.Face, Icons.Rounded.Pets, Icons.Rounded.Star,
    Icons.Rounded.Favorite, Icons.Rounded.RocketLaunch, Icons.Rounded.Bolt, Icons.Rounded.Cloud
)
val AvatarColors = listOf(
    Color(0xFF185FA5), Color(0xFF0F6E56), Color(0xFF993C1D), Color(0xFF534AB7),
    Color(0xFFA32D2D), Color(0xFF3B6D11), Color(0xFF854F0B), Color(0xFF993556)
)

@Composable
fun Avatar(index: Int, size: Dp = 44.dp) {
    val i = index.coerceIn(0, AvatarIcons.lastIndex)
    Box(
        Modifier.size(size).clip(CircleShape).background(AvatarColors[i].copy(alpha = 0.16f)),
        contentAlignment = Alignment.Center
    ) { Icon(AvatarIcons[i], null, tint = AvatarColors[i], modifier = Modifier.size(size * 0.55f)) }
}

fun categoryIcon(c: Category): ImageVector = when (c) {
    Category.PHOTO -> Icons.Rounded.Image
    Category.VIDEO -> Icons.Rounded.Videocam
    Category.MUSIC -> Icons.Rounded.MusicNote
    Category.DOC -> Icons.Rounded.Description
    Category.APK -> Icons.Rounded.Android
    Category.ZIP -> Icons.Rounded.FolderZip
    Category.OTHER -> Icons.Rounded.InsertDriveFile
}

fun categoryTint(c: Category): Color = when (c) {
    Category.PHOTO -> Color(0xFF993556)
    Category.VIDEO -> Color(0xFF534AB7)
    Category.MUSIC -> Color(0xFF993C1D)
    Category.DOC -> Color(0xFF185FA5)
    Category.APK -> Color(0xFF3B6D11)
    Category.ZIP -> Color(0xFF854F0B)
    Category.OTHER -> Color(0xFF5F5E5A)
}

@Composable
fun CategoryBadge(c: Category, size: Dp = 44.dp) {
    Box(
        Modifier.size(size).clip(RoundedCornerShape(12.dp)).background(categoryTint(c).copy(alpha = 0.14f)),
        contentAlignment = Alignment.Center
    ) { Icon(categoryIcon(c), null, tint = categoryTint(c), modifier = Modifier.size(size * 0.5f)) }
}

@Composable
fun statusColor(s: TStatus): Color = when (s) {
    TStatus.DONE -> Color(0xFF1D9E75)
    TStatus.FAILED -> Color(0xFFE24B4A)
    TStatus.CANCELLED, TStatus.DECLINED -> Color(0xFFBA7517)
    else -> MaterialTheme.colorScheme.primary
}

fun statusText(s: TStatus): String = when (s) {
    TStatus.PREPARING -> "Preparing"
    TStatus.WAITING -> "Waiting"
    TStatus.ACTIVE -> "In progress"
    TStatus.DONE -> "Completed"
    TStatus.FAILED -> "Failed"
    TStatus.CANCELLED -> "Cancelled"
    TStatus.DECLINED -> "Declined"
}

@Composable
fun StatusPill(s: TStatus) {
    val c = statusColor(s)
    Text(
        statusText(s), color = c, style = MaterialTheme.typography.labelSmall,
        modifier = Modifier.clip(RoundedCornerShape(10.dp)).background(c.copy(alpha = 0.14f)).padding(horizontal = 8.dp, vertical = 3.dp)
    )
}

@Composable
fun EmptyState(icon: ImageVector, title: String, body: String, modifier: Modifier = Modifier, action: (@Composable () -> Unit)? = null) {
    Column(
        modifier.fillMaxWidth().padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        Box(
            Modifier.size(64.dp).clip(CircleShape).background(MaterialTheme.colorScheme.primaryContainer),
            contentAlignment = Alignment.Center
        ) { Icon(icon, null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(30.dp)) }
        Text(title, style = MaterialTheme.typography.titleMedium, textAlign = TextAlign.Center)
        Text(body, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant, textAlign = TextAlign.Center)
        if (action != null) action()
    }
}

@Composable
fun Radar(modifier: Modifier = Modifier.size(150.dp)) {
    val t = rememberInfiniteTransition(label = "radar")
    val p by t.animateFloat(0f, 1f, infiniteRepeatable(tween(2400, easing = LinearEasing), RepeatMode.Restart), label = "p")
    val col = MaterialTheme.colorScheme.primary
    Canvas(modifier) {
        val maxR = size.minDimension / 2
        for (k in 0..2) {
            val q = (p + k / 3f) % 1f
            drawCircle(col.copy(alpha = (1f - q) * 0.45f), radius = maxR * q, style = Stroke(width = 3.dp.toPx()))
        }
        drawCircle(col, radius = 9.dp.toPx())
    }
}
