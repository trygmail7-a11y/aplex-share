package com.aplex.share.ui

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.spring
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.aplex.share.core.*
import com.aplex.share.data.*
import kotlinx.coroutines.delay

@Composable
fun ReceiveScreen(onClose: () -> Unit, onQr: () -> Unit, onScan: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    Column(Modifier.fillMaxSize().padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Row(Modifier.fillMaxWidth()) { IconButton(onClick = onClose) { Icon(Icons.Rounded.Close, "Close") } }
        Spacer(Modifier.weight(1f))
        Radar(Modifier.size(200.dp))
        Spacer(Modifier.height(16.dp))
        Text("Ready to receive", style = MaterialTheme.typography.headlineSmall)
        Text("Visible as \"${Prefs.deviceName}\"", color = cs.onSurfaceVariant)
        Spacer(Modifier.height(8.dp))
        Text(
            if (NearbyEngine.advertising) "On the other phone, open Aplex Share, pick files, and choose this device."
            else "Starting nearby sharing…",
            textAlign = TextAlign.Center, style = MaterialTheme.typography.bodyMedium, color = cs.onSurfaceVariant
        )
        Spacer(Modifier.weight(1f))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedButton(onClick = onQr, Modifier.weight(1f)) { Icon(Icons.Rounded.QrCode2, null, Modifier.size(18.dp)); Spacer(Modifier.width(6.dp)); Text("Show my QR", maxLines = 1) }
            OutlinedButton(onClick = onScan, Modifier.weight(1f)) { Icon(Icons.Rounded.QrCodeScanner, null, Modifier.size(18.dp)); Spacer(Modifier.width(6.dp)); Text("Scan QR", maxLines = 1) }
        }
    }
}

@Composable
fun MyQrScreen(onClose: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    val s = NearbyEngine.qrSession
    LaunchedEffect(Unit) { if (NearbyEngine.qrSession == null) NearbyEngine.createQr() }
    DisposableEffect(Unit) { onDispose { NearbyEngine.clearQr() } }
    val bmp = remember(s?.pid) { s?.let { QrUtil.bitmap(NearbyEngine.qrString(it), 720)?.asImageBitmap() } }
    val remaining by produceState(0L, s) {
        while (true) { value = ((s?.expiresAt ?: 0L) - System.currentTimeMillis()).coerceAtLeast(0); delay(500) }
    }
    Column(Modifier.fillMaxSize().padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Row(Modifier.fillMaxWidth()) { IconButton(onClick = onClose) { Icon(Icons.Rounded.Close, "Close") } }
        Spacer(Modifier.weight(1f))
        Text("Scan to connect", style = MaterialTheme.typography.headlineSmall)
        Text("Ask the other phone to open Aplex Share and tap Scan QR.", textAlign = TextAlign.Center, color = cs.onSurfaceVariant, style = MaterialTheme.typography.bodyMedium)
        Spacer(Modifier.height(20.dp))
        Box(Modifier.size(260.dp).clip(RoundedCornerShape(24.dp)).background(Color.White).padding(14.dp), contentAlignment = Alignment.Center) {
            if (s != null && bmp != null) Image(bmp, "QR code", Modifier.fillMaxSize())
            else Text("QR expired", color = Color.Black)
        }
        Spacer(Modifier.height(14.dp))
        Text(
            if (s != null) "Expires in ${formatDuration(remaining)} · works once" else "Create a new code to keep going",
            color = cs.onSurfaceVariant, style = MaterialTheme.typography.bodySmall
        )
        Text("Device: ${Prefs.deviceName}", color = cs.onSurfaceVariant, style = MaterialTheme.typography.bodySmall)
        Spacer(Modifier.height(16.dp))
        Button(onClick = { NearbyEngine.createQr() }) {
            Icon(Icons.Rounded.Refresh, null, Modifier.size(18.dp)); Spacer(Modifier.width(6.dp)); Text("Refresh QR")
        }
        Spacer(Modifier.weight(1f))
    }
}

@Composable
fun ProgressScreen(id: String, onClose: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    val t = NearbyEngine.transfers[id]
    if (t == null) { LaunchedEffect(Unit) { onClose() }; return }
    val sending = t.direction == Direction.SENT
    val p = if (t.total > 0) t.done.toFloat() / t.total else 0f

    Column(Modifier.fillMaxSize().padding(horizontal = 20.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onClose) { Icon(Icons.Rounded.Close, "Close") }
            Text((if (sending) "Sending to " else "Receiving from ") + t.peerName, style = MaterialTheme.typography.titleMedium, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
        Spacer(Modifier.height(12.dp))
        Text("${(p * 100).toInt()}%", fontSize = 48.sp, fontWeight = FontWeight.SemiBold, color = cs.primary)
        LinearProgressIndicator(progress = { p }, Modifier.fillMaxWidth().height(8.dp).clip(CircleShape))
        Spacer(Modifier.height(8.dp))
        Text("${formatSize(t.done)} of ${formatSize(t.total)}", color = cs.onSurfaceVariant, style = MaterialTheme.typography.bodyMedium)
        Row(Modifier.fillMaxWidth().padding(top = 4.dp), horizontalArrangement = Arrangement.SpaceBetween) {
            Text(if (t.status == TStatus.ACTIVE && t.speed > 0) formatSpeed(t.speed) else "—", style = MaterialTheme.typography.bodySmall, color = cs.onSurfaceVariant)
            val eta = if (t.status == TStatus.ACTIVE && t.speed > 0) formatDuration((t.total - t.done) * 1000 / t.speed) + " left" else ""
            Text(eta, style = MaterialTheme.typography.bodySmall, color = cs.onSurfaceVariant)
        }
        Spacer(Modifier.height(8.dp))
        Text(
            when (t.status) {
                TStatus.PREPARING, TStatus.WAITING -> "Waiting for ${t.peerName} to accept…"
                TStatus.ACTIVE -> "Transferring ${t.files.size} file(s)"
                TStatus.DONE -> "Completed"
                else -> t.error ?: statusText(t.status)
            },
            color = if (t.status == TStatus.FAILED) statusColor(TStatus.FAILED) else cs.onSurface, style = MaterialTheme.typography.bodyMedium
        )
        Spacer(Modifier.height(8.dp))
        LazyColumn(Modifier.weight(1f)) {
            items(t.files.size) { i ->
                val f = t.files[i]
                val st = t.fileStatus[i]
                Row(Modifier.fillMaxWidth().padding(vertical = 5.dp), verticalAlignment = Alignment.CenterVertically) {
                    CategoryBadge(categoryOf(f.name, f.mime), 36.dp)
                    Spacer(Modifier.width(10.dp))
                    Column(Modifier.weight(1f)) {
                        Text(f.name, maxLines = 1, overflow = TextOverflow.Ellipsis, style = MaterialTheme.typography.bodyMedium)
                        Text(formatSize(f.size), style = MaterialTheme.typography.bodySmall, color = cs.onSurfaceVariant)
                        if (st == TStatus.ACTIVE && f.size > 0) {
                            LinearProgressIndicator(progress = { ((t.fileProgress[i] ?: 0L).toFloat() / f.size).coerceIn(0f, 1f) }, Modifier.fillMaxWidth().padding(top = 3.dp))
                        }
                    }
                    if (st == TStatus.DONE) Icon(Icons.Rounded.CheckCircle, null, tint = Color(0xFF1D9E75))
                }
            }
        }
        Row(Modifier.fillMaxWidth().padding(vertical = 12.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            if (t.isActive) {
                OutlinedButton(onClick = { NearbyEngine.cancel(t) }, Modifier.weight(1f)) { Text("Cancel transfer") }
            } else {
                if (t.status == TStatus.FAILED && sending) Button(onClick = { NearbyEngine.retry(t); onClose() }, Modifier.weight(1f)) { Text("Retry") }
                OutlinedButton(onClick = onClose, Modifier.weight(1f)) { Text("Close") }
            }
        }
    }
}

@Composable
fun SuccessScreen(id: String, onDone: () -> Unit, onViewFiles: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    val t = NearbyEngine.transfers[id]
    if (t == null) { LaunchedEffect(Unit) { onDone() }; return }
    val scale = remember { Animatable(0f) }
    LaunchedEffect(Unit) { scale.animateTo(1f, spring(Spring.DampingRatioMediumBouncy, Spring.StiffnessLow)) }
    val sent = t.direction == Direction.SENT

    Column(Modifier.fillMaxSize().padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Spacer(Modifier.weight(1f))
        Box(Modifier.size(112.dp).scale(scale.value).clip(CircleShape).background(Color(0xFF1D9E75)), contentAlignment = Alignment.Center) {
            Icon(Icons.Rounded.Check, null, tint = Color.White, modifier = Modifier.size(64.dp))
        }
        Spacer(Modifier.height(20.dp))
        Text("Transfer Completed!", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.SemiBold)
        Text(if (sent) "Successfully sent" else "Successfully received", color = cs.onSurfaceVariant)
        Spacer(Modifier.height(16.dp))
        Card(colors = CardDefaults.cardColors(containerColor = cs.surfaceVariant)) {
            Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                StatRow("Files", "${t.files.size}")
                StatRow("Total size", formatSize(t.total))
                StatRow(if (sent) "Sent to" else "Received from", t.peerName)
                StatRow("Duration", formatDuration(t.endedAt - t.startedAt))
            }
        }
        Spacer(Modifier.height(16.dp))
        Text(
            "Awesome! Your files have been transferred successfully.\n\nEverything is done. Thank you for using Aplex Share!",
            textAlign = TextAlign.Center, color = cs.onSurfaceVariant, style = MaterialTheme.typography.bodyMedium
        )
        Spacer(Modifier.weight(1f))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedButton(onClick = onViewFiles, Modifier.weight(1f)) { Text("View Files") }
            Button(onClick = onDone, Modifier.weight(1f)) { Text("Done") }
        }
    }
}

@Composable
private fun StatRow(k: String, v: String) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
        Text(k, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Text(v, fontWeight = FontWeight.Medium, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.padding(start = 16.dp))
    }
}

@Composable
fun ConnRequestDialog(r: ConnRequest) {
    AlertDialog(
        onDismissRequest = { NearbyEngine.rejectConnection() },
        title = { Text(if (r.incoming) "${r.name} wants to connect" else "Connect to ${r.name}?") },
        text = {
            Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.fillMaxWidth()) {
                Text("Make sure this code is the same on both phones.", textAlign = TextAlign.Center)
                Spacer(Modifier.height(12.dp))
                Text(r.digits, fontSize = 36.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary, letterSpacing = 6.sp)
            }
        },
        confirmButton = { Button(onClick = { NearbyEngine.acceptConnection() }) { Text("Accept") } },
        dismissButton = { TextButton(onClick = { NearbyEngine.rejectConnection() }) { Text("Decline") } }
    )
}

@Composable
fun OfferDialog(t: TransferState) {
    val cs = MaterialTheme.colorScheme
    val summary = t.files.groupBy { categoryOf(it.name, it.mime) }
        .entries.joinToString(" · ") { "${it.value.size} ${categoryLabel(it.key)}" }
    AlertDialog(
        onDismissRequest = { },
        title = { Text("${t.peerName} wants to send files") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text("${t.files.size} file(s) · ${formatSize(t.total)}", fontWeight = FontWeight.Medium)
                Text(summary, style = MaterialTheme.typography.bodySmall, color = cs.onSurfaceVariant)
                LazyColumn(Modifier.heightIn(max = 220.dp)) {
                    items(t.files.take(50)) { f ->
                        Row(Modifier.fillMaxWidth().padding(vertical = 3.dp), verticalAlignment = Alignment.CenterVertically) {
                            Text(f.name, Modifier.weight(1f), maxLines = 1, overflow = TextOverflow.Ellipsis, style = MaterialTheme.typography.bodyMedium)
                            Text(formatSize(f.size), style = MaterialTheme.typography.bodySmall, color = cs.onSurfaceVariant, modifier = Modifier.padding(start = 8.dp))
                        }
                    }
                    if (t.files.size > 50) item { Text("…and ${t.files.size - 50} more", style = MaterialTheme.typography.bodySmall, color = cs.onSurfaceVariant) }
                }
            }
        },
        confirmButton = { Button(onClick = { NearbyEngine.acceptOffer(t) }) { Text("Accept") } },
        dismissButton = { TextButton(onClick = { NearbyEngine.declineOffer(t) }) { Text("Decline") } }
    )
}

@Composable
fun BoxScope.PairedBanner(name: String) {
    val s = remember { Animatable(0.6f) }
    LaunchedEffect(Unit) { s.animateTo(1f, spring(Spring.DampingRatioMediumBouncy)) }
    Surface(
        shape = RoundedCornerShape(24.dp), color = MaterialTheme.colorScheme.primaryContainer, shadowElevation = 8.dp,
        modifier = Modifier.align(Alignment.TopCenter).padding(top = 64.dp).scale(s.value)
    ) {
        Row(Modifier.padding(horizontal = 18.dp, vertical = 12.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Rounded.CheckCircle, null, tint = Color(0xFF1D9E75))
            Spacer(Modifier.width(8.dp))
            Text("Connected to $name", color = MaterialTheme.colorScheme.onPrimaryContainer, fontWeight = FontWeight.Medium)
        }
    }
}
