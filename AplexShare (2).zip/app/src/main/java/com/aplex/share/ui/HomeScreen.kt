package com.aplex.share.ui

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.aplex.share.core.*
import com.aplex.share.data.*

private val HeroBrush = Brush.linearGradient(listOf(Color(0xFF0C447C), Color(0xFF185FA5), Color(0xFF378ADD)))
private val SendBrush = Brush.linearGradient(listOf(Color(0xFF185FA5), Color(0xFF378ADD)))

@Composable
fun HomeScreen(goTab: (Int) -> Unit, open: (Overlay) -> Unit, openCat: (Category) -> Unit) {
    val ctx = LocalContext.current
    val ensure = LocalEnsure.current
    val cs = MaterialTheme.colorScheme
    val connected = NearbyEngine.peers.values.filter { it.state == PeerState.CONNECTED }
    val nearby = NearbyEngine.peers.values.filter { it.state != PeerState.CONNECTED }

    LazyColumn(
        Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // ---- hero with Quick Share switch ----
        item {
            Column(
                Modifier.fillMaxWidth().clip(RoundedCornerShape(28.dp)).background(HeroBrush).padding(18.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(Modifier.size(46.dp).clip(RoundedCornerShape(15.dp)).background(Color.White.copy(alpha = 0.2f)), contentAlignment = Alignment.Center) {
                        Icon(Icons.Rounded.Share, null, tint = Color.White)
                    }
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        Text("Aplex Share", color = Color.White, fontWeight = FontWeight.SemiBold, fontSize = 21.sp)
                        Text("Hi, ${Prefs.deviceName}", color = Color.White.copy(alpha = 0.8f), style = MaterialTheme.typography.bodySmall, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    }
                    IconButton(onClick = { goTab(4) }) { Icon(Icons.Rounded.Settings, "Settings", tint = Color.White) }
                }
                Row(
                    Modifier.fillMaxWidth().clip(RoundedCornerShape(20.dp)).background(Color.White.copy(alpha = 0.16f)).padding(start = 14.dp, end = 10.dp, top = 10.dp, bottom = 10.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(Icons.Rounded.WifiTethering, null, tint = Color.White)
                    Spacer(Modifier.width(10.dp))
                    Column(Modifier.weight(1f)) {
                        Text("Quick Share", color = Color.White, fontWeight = FontWeight.Medium)
                        Text(
                            when {
                                !NearbyEngine.permsOk -> "Allow access to turn on"
                                !Prefs.nearbyEnabled -> "Off · nearby phones can't see you"
                                connected.isNotEmpty() -> "Connected to ${connected.first().name}"
                                nearby.isNotEmpty() -> "${nearby.size} device(s) nearby"
                                else -> "On · always ready, works offline"
                            },
                            color = Color.White.copy(alpha = 0.85f), style = MaterialTheme.typography.bodySmall
                        )
                    }
                    Switch(
                        checked = Prefs.nearbyEnabled && NearbyEngine.permsOk,
                        onCheckedChange = { on ->
                            Prefs.nearbyEnabled = on; Prefs.save()
                            if (on) ensure(Permissions.nearby()) { NearbyEngine.refreshPerms(ctx); NearbyEngine.settingsChanged() }
                            else NearbyEngine.settingsChanged()
                        },
                        colors = SwitchDefaults.colors(
                            checkedThumbColor = Color.White, checkedTrackColor = Color(0xFF1D9E75), checkedBorderColor = Color.Transparent,
                            uncheckedThumbColor = Color.White, uncheckedTrackColor = Color.White.copy(alpha = 0.3f), uncheckedBorderColor = Color.Transparent
                        )
                    )
                }
            }
        }

        item { RadioSetupCard(autoRun = false, showWhenOk = false) }

        // ---- send / receive ----
        item {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                BigAction("Send", "Pick files", Icons.Rounded.ArrowUpward, true, Modifier.weight(1f)) { openCat(Category.PHOTO) }
                BigAction("Receive", "Get files", Icons.Rounded.ArrowDownward, false, Modifier.weight(1f)) {
                    ensure(Permissions.nearby()) { open(Overlay.Receive) }
                }
            }
        }

        // ---- nearby ----
        item {
            Card(
                Modifier.fillMaxWidth(), shape = RoundedCornerShape(24.dp),
                colors = CardDefaults.cardColors(containerColor = cs.surface), border = BorderStroke(0.5.dp, cs.outlineVariant)
            ) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("Nearby devices", fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f))
                        TextButton(onClick = { goTab(2) }) { Text("Open Connect") }
                    }
                    if (nearby.isEmpty() && connected.isEmpty()) {
                        Text(
                            if (!NearbyEngine.permsOk) "Allow nearby access to find devices."
                            else if (!Prefs.nearbyEnabled) "Turn on Quick Share to see devices."
                            else "Searching… open Aplex Share on the other phone.",
                            style = MaterialTheme.typography.bodyMedium, color = cs.onSurfaceVariant
                        )
                        if (!NearbyEngine.permsOk) Button(onClick = { ensure(Permissions.nearby()) { } }) { Text("Allow access") }
                    } else {
                        Row(horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                            (connected + nearby).take(4).forEach { p ->
                                Column(Modifier.width(68.dp).clickable { goTab(2) }, horizontalAlignment = Alignment.CenterHorizontally) {
                                    Avatar(p.avatar, 50.dp)
                                    Text(p.name, style = MaterialTheme.typography.labelSmall, maxLines = 1, overflow = TextOverflow.Ellipsis, color = cs.onSurfaceVariant)
                                }
                            }
                        }
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedButton(onClick = { ensure(Permissions.nearby()) { open(Overlay.MyQr) } }, Modifier.weight(1f), shape = RoundedCornerShape(14.dp)) {
                            Icon(Icons.Rounded.QrCode2, null, Modifier.size(18.dp)); Spacer(Modifier.width(6.dp)); Text("Show my QR", maxLines = 1)
                        }
                        OutlinedButton(onClick = { ensure(Permissions.nearby()) { QrScan.start(ctx) } }, Modifier.weight(1f), shape = RoundedCornerShape(14.dp)) {
                            Icon(Icons.Rounded.QrCodeScanner, null, Modifier.size(18.dp)); Spacer(Modifier.width(6.dp)); Text("Scan QR", maxLines = 1)
                        }
                    }
                }
            }
        }

        // ---- quick access ----
        item {
            Text("Quick access", fontWeight = FontWeight.SemiBold, modifier = Modifier.padding(bottom = 10.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                QuickItem("Photos", Category.PHOTO, openCat)
                QuickItem("Videos", Category.VIDEO, openCat)
                QuickItem("Apps", Category.APK, openCat)
                QuickItem("Music", Category.MUSIC, openCat)
                QuickItem("Docs", Category.DOC, openCat)
            }
        }

        item { Text("Recent transfers", fontWeight = FontWeight.SemiBold) }
        val recent = HistoryStore.records.take(3)
        if (recent.isEmpty()) {
            item { EmptyState(Icons.Rounded.History, "No transfers yet", "Send or receive your first file and it will show up here.") }
        } else {
            items(recent.size) { i -> RecordRow(recent[i]) { goTab(3) } }
        }
    }
}

@Composable
private fun BigAction(title: String, sub: String, icon: ImageVector, filled: Boolean, modifier: Modifier, onClick: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    val fg = if (filled) Color.White else cs.onPrimaryContainer
    val base = modifier.clip(RoundedCornerShape(24.dp))
    Column(
        (if (filled) base.background(SendBrush) else base.background(cs.primaryContainer)).clickable(onClick = onClick).padding(vertical = 24.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Box(Modifier.size(52.dp).clip(RoundedCornerShape(18.dp)).background(fg.copy(alpha = 0.16f)), contentAlignment = Alignment.Center) {
            Icon(icon, null, tint = fg, modifier = Modifier.size(30.dp))
        }
        Spacer(Modifier.height(8.dp))
        Text(title, color = fg, fontWeight = FontWeight.SemiBold, fontSize = 18.sp)
        Text(sub, color = fg.copy(alpha = 0.8f), style = MaterialTheme.typography.bodySmall)
    }
}

@Composable
private fun QuickItem(label: String, cat: Category, onClick: (Category) -> Unit) {
    Column(Modifier.width(60.dp).clickable { onClick(cat) }, horizontalAlignment = Alignment.CenterHorizontally) {
        CategoryBadge(cat, 52.dp)
        Spacer(Modifier.height(4.dp))
        Text(label, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

@Composable
fun RecordRow(r: TransferRecord, onClick: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    val first = r.files.firstOrNull()
    val cat = first?.let { categoryOf(it.name, it.mime) } ?: Category.OTHER
    Row(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).clickable(onClick = onClick).padding(vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        CategoryBadge(cat)
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            val title = (first?.name ?: "Files") + if (r.fileCount > 1) "  +${r.fileCount - 1} more" else ""
            Text(title, maxLines = 1, overflow = TextOverflow.Ellipsis)
            val dir = if (r.direction == Direction.SENT) "To" else "From"
            Text("$dir ${r.peer} · ${formatSize(r.totalBytes)} · ${formatDate(r.startedAt)}", style = MaterialTheme.typography.bodySmall, color = cs.onSurfaceVariant, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
        Spacer(Modifier.width(8.dp))
        StatusPill(r.status)
    }
}
