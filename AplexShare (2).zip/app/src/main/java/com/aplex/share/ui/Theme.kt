package com.aplex.share.ui

import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp

private val Light = lightColorScheme(
    primary = Color(0xFF185FA5), onPrimary = Color.White,
    primaryContainer = Color(0xFFE6F1FB), onPrimaryContainer = Color(0xFF0C447C),
    secondaryContainer = Color(0xFFE6F1FB), onSecondaryContainer = Color(0xFF0C447C),
    background = Color(0xFFF6F9FE), onBackground = Color(0xFF0F1B2D),
    surface = Color.White, onSurface = Color(0xFF0F1B2D),
    surfaceVariant = Color(0xFFEAF1FA), onSurfaceVariant = Color(0xFF55657A),
    outlineVariant = Color(0xFFD5E0EE)
)

private val Dark = darkColorScheme(
    primary = Color(0xFF5AA0F2), onPrimary = Color(0xFF04213F),
    primaryContainer = Color(0xFF14315A), onPrimaryContainer = Color(0xFFCFE3FA),
    secondaryContainer = Color(0xFF14315A), onSecondaryContainer = Color(0xFFCFE3FA),
    background = Color(0xFF0B1426), onBackground = Color(0xFFE6EEF9),
    surface = Color(0xFF111C33), onSurface = Color(0xFFE6EEF9),
    surfaceVariant = Color(0xFF1A2842), onSurfaceVariant = Color(0xFFA8B7CE),
    outlineVariant = Color(0xFF263754)
)

@Composable
fun AplexTheme(dark: Boolean, content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = if (dark) Dark else Light,
        shapes = Shapes(
            small = RoundedCornerShape(12.dp),
            medium = RoundedCornerShape(16.dp),
            large = RoundedCornerShape(24.dp)
        ),
        content = content
    )
}
