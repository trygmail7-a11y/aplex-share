package com.aplex.share.ui

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.aplex.share.core.*
import com.aplex.share.data.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

private val TABS = listOf(
    Category.PHOTO to "Photos", Category.VIDEO to "Videos", Category.MUSIC to "Music",
    Category.APK to "Apps", Category.OTHER to "Selected"
)

@Composable
fun FilesScreen(cat: Category, onCat: (Category) -> Unit, goConnect: () -> Unit) {
    val ctx = LocalContext.current
    val ensure = LocalEnsure.current
    val scope = rememberCoroutineScope()
    val cs = MaterialTheme.colorScheme

    var query by remember { mutableStateOf("") }
    var sort by remember { mutableIntStateOf(2) } // 0 name, 1 size, 2 date
    var sortMenu by remember { mutableStateOf(false) }
    var loaded by remember { mutableStateOf<List<SendItem>>(emptyList()) }
    var loading by remember { mutableStateOf(false) }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris ->
        if (uris.isNotEmpty()) scope.launch {
            val list = withContext(Dispatchers.IO) { MediaRepo.fromUris(ctx, uris) }
            Selection.addAll(list)
            if (list.size < uris.size) toast(ctx, "Some files couldn't be read")
            onCat(Category.OTHER)
        }
    }
    val folderPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocumentTree()) { uri ->
        if (uri != null) scope.launch {
            loading = true
            val list = withContext(Dispatchers.IO) { MediaRepo.fromTree(ctx, uri) }
            loading = false
            if (list.isEmpty()) toast(ctx, "That folder is empty") else { Selection.addAll(list); onCat(Category.OTHER) }
        }
    }

    fun load() {
        when (cat) {
            Category.OTHER -> { }
            Category.APK -> scope.launch {
                loading = true
                loaded = withContext(Dispatchers.IO) { MediaRepo.apps(ctx) }
                loading = false
            }
            else -> ensure(Permissions.media(cat)) {
                scope.launch {
                    loading = true
                    loaded = withContext(Dispatchers.IO) { MediaRepo.query(ctx, cat) }
                    loading = false
                }
            }
        }
    }
    LaunchedEffect(cat) { loaded = emptyList(); load() }

    val base = if (cat == Category.OTHER) Selection.items.values.toList() else loaded
    val shown = remember(base, query, sort) {
        val f = if (query.isBlank()) base else base.filter { it.name.contains(query, ignoreCase = true) }
        when (sort) {
            0 -> f.sortedBy { it.name.lowercase() }
            1 -> f.sortedByDescending { it.size }
            else -> f.sortedByDescending { it.dateMs }
        }
    }
    val selCount = Selection.items.size

    Column(Modifier.fillMaxSize()) {
        Text("Files", style = MaterialTheme.typography.headlineSmall, modifier = Modifier.padding(start = 16.dp, top = 12.dp, end = 16.dp))
        OutlinedTextField(
            value = query, onValueChange = { query = it }, singleLine = true,
            placeholder = { Text("Search files") },
            leadingIcon = { Icon(Icons.Rounded.Search, null) },
            trailingIcon = { if (query.isNotEmpty()) IconButton(onClick = { query = "" }) { Icon(Icons.Rounded.Close, "Clear") } },
            modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp),
            shape = RoundedCornerShape(16.dp)
        )
        Row(Modifier.horizontalScroll(rememberScrollState()).padding(horizontal = 16.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            TABS.forEach { (c, label) ->
                FilterChip(
                    selected = cat == c, onClick = { onCat(c) },
                    label = { Text(if (c == Category.OTHER && selCount > 0) "$label ($selCount)" else label) }
                )
            }
        }
        Row(Modifier.horizontalScroll(rememberScrollState()).padding(horizontal = 16.dp, vertical = 4.dp), horizontalArrangement = Arrangement.spacedBy(4.dp), verticalAlignment = Alignment.CenterVertically) {
            TextButton(onClick = { picker.launch(arrayOf("*/*")) }) {
                Icon(Icons.Rounded.FolderOpen, null, Modifier.size(18.dp)); Spacer(Modifier.width(4.dp)); Text("Documents & more")
            }
            TextButton(onClick = { folderPicker.launch(null) }) {
                Icon(Icons.Rounded.Folder, null, Modifier.size(18.dp)); Spacer(Modifier.width(4.dp)); Text("Folder")
            }
            TextButton(onClick = { if (shown.all { Selection.isSelected(it) } && shown.isNotEmpty()) Selection.removeAll(shown) else Selection.addAll(shown) }) {
                Text(if (shown.isNotEmpty() && shown.all { Selection.isSelected(it) }) "Deselect all" else "Select all")
            }
            Box {
                TextButton(onClick = { sortMenu = true }) {
                    Icon(Icons.Rounded.Sort, null, Modifier.size(18.dp)); Spacer(Modifier.width(4.dp))
                    Text(listOf("Name", "Size", "Date")[sort])
                }
                DropdownMenu(expanded = sortMenu, onDismissRequest = { sortMenu = false }) {
                    listOf("Name", "Size", "Date").forEachIndexed { i, s -> DropdownMenuItem(text = { Text("Sort by $s") }, onClick = { sort = i; sortMenu = false }) }
                }
            }
        }

        Box(Modifier.weight(1f)) {
            when {
                loading -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { CircularProgressIndicator() }
                shown.isEmpty() -> {
                    val needPerm = cat != Category.OTHER && cat != Category.APK && !Permissions.has(ctx, Permissions.media(cat))
                    when {
                        needPerm -> EmptyState(Icons.Rounded.Image, "Allow access to your files", "Aplex Share only reads what you choose to send.", Modifier.align(Alignment.Center)) {
                            Button(onClick = { load() }) { Text("Allow access") }
                        }
                        cat == Category.OTHER -> EmptyState(Icons.Rounded.FolderOpen, "Nothing selected", "Choose documents, ZIP files, or a whole folder to send.", Modifier.align(Alignment.Center)) {
                            Button(onClick = { picker.launch(arrayOf("*/*")) }) { Text("Choose files") }
                        }
                        query.isNotBlank() -> EmptyState(Icons.Rounded.Search, "No matches", "Try a different search.", Modifier.align(Alignment.Center))
                        else -> EmptyState(Icons.Rounded.FolderOpen, "Nothing here", "No files found in this category.", Modifier.align(Alignment.Center))
                    }
                }
                else -> LazyColumn(contentPadding = PaddingValues(horizontal = 16.dp, vertical = 4.dp)) {
                    items(shown, key = { it.key }) { item -> FileRow(item) }
                }
            }
        }

        if (selCount > 0) {
            Surface(tonalElevation = 3.dp, shadowElevation = 8.dp) {
                Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("$selCount selected", style = MaterialTheme.typography.titleSmall)
                        Text(formatSize(Selection.totalSize()), style = MaterialTheme.typography.bodySmall, color = cs.onSurfaceVariant)
                    }
                    TextButton(onClick = { Selection.clear() }) { Text("Clear") }
                    Spacer(Modifier.width(4.dp))
                    Button(onClick = goConnect) {
                        Icon(Icons.Rounded.Send, null, Modifier.size(18.dp)); Spacer(Modifier.width(6.dp)); Text("Send")
                    }
                }
            }
        }
    }
}

@Composable
private fun FileRow(item: SendItem) {
    val ctx = LocalContext.current
    val cs = MaterialTheme.colorScheme
    val selected = Selection.isSelected(item)
    val thumb = rememberThumb(item.uri, item.category == Category.PHOTO || item.category == Category.VIDEO)
    Row(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).clickable { Selection.toggle(item) }.padding(vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        if (thumb != null) {
            Image(thumb, null, Modifier.size(48.dp).clip(RoundedCornerShape(12.dp)), contentScale = ContentScale.Crop)
        } else CategoryBadge(item.category, 48.dp)
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(item.name, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text("${typeLabel(item.name)} · ${formatSize(item.size)}", style = MaterialTheme.typography.bodySmall, color = cs.onSurfaceVariant)
        }
        if (item.uri.scheme == "content") {
            IconButton(onClick = { openFile(ctx, item.uri.toString(), item.mime) }) { Icon(Icons.Rounded.Visibility, "Preview", tint = cs.onSurfaceVariant) }
        }
        Checkbox(checked = selected, onCheckedChange = { Selection.toggle(item) })
    }
}
