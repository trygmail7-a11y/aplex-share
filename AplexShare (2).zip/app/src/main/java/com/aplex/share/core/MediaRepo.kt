package com.aplex.share.core

import android.content.ContentUris
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.MediaStore
import android.provider.OpenableColumns
import androidx.documentfile.provider.DocumentFile
import com.aplex.share.data.Category
import com.aplex.share.data.SendItem
import java.io.File

object MediaRepo {

    /** Photos, videos or music from MediaStore. Needs the matching media permission. */
    fun query(ctx: Context, cat: Category): List<SendItem> {
        val base = when (cat) {
            Category.PHOTO -> MediaStore.Images.Media.EXTERNAL_CONTENT_URI
            Category.VIDEO -> MediaStore.Video.Media.EXTERNAL_CONTENT_URI
            Category.MUSIC -> MediaStore.Audio.Media.EXTERNAL_CONTENT_URI
            else -> return emptyList()
        }
        val proj = arrayOf(
            MediaStore.MediaColumns._ID, MediaStore.MediaColumns.DISPLAY_NAME, MediaStore.MediaColumns.SIZE,
            MediaStore.MediaColumns.MIME_TYPE, MediaStore.MediaColumns.DATE_MODIFIED
        )
        val out = ArrayList<SendItem>()
        try {
            ctx.contentResolver.query(base, proj, null, null, "${MediaStore.MediaColumns.DATE_MODIFIED} DESC")?.use { c ->
                val iId = c.getColumnIndexOrThrow(MediaStore.MediaColumns._ID)
                val iName = c.getColumnIndexOrThrow(MediaStore.MediaColumns.DISPLAY_NAME)
                val iSize = c.getColumnIndexOrThrow(MediaStore.MediaColumns.SIZE)
                val iMime = c.getColumnIndexOrThrow(MediaStore.MediaColumns.MIME_TYPE)
                val iDate = c.getColumnIndexOrThrow(MediaStore.MediaColumns.DATE_MODIFIED)
                while (c.moveToNext()) {
                    val name = c.getString(iName) ?: "file"
                    out.add(
                        SendItem(
                            ContentUris.withAppendedId(base, c.getLong(iId)), name, c.getLong(iSize),
                            c.getString(iMime) ?: guessMime(name), name, cat, c.getLong(iDate) * 1000
                        )
                    )
                }
            }
        } catch (_: SecurityException) { }
        return out
    }

    /** Installed apps that have a launcher icon. Sends the base APK only. */
    fun apps(ctx: Context): List<SendItem> {
        val pm = ctx.packageManager
        val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val seen = HashSet<String>()
        val out = ArrayList<SendItem>()
        for (ri in pm.queryIntentActivities(intent, 0)) {
            val info = ri.activityInfo?.applicationInfo ?: continue
            if (!seen.add(info.packageName)) continue
            val f = File(info.sourceDir)
            if (!f.exists()) continue
            val label = (info.loadLabel(pm)?.toString() ?: info.packageName).replace('/', '_')
            val name = "$label.apk"
            out.add(
                SendItem(
                    Uri.fromFile(f), name, f.length(), "application/vnd.android.package-archive",
                    name, Category.APK, f.lastModified()
                )
            )
        }
        return out.sortedBy { it.name.lowercase() }
    }

    /** Files chosen with the system document picker (documents, ZIP, anything). */
    fun fromUris(ctx: Context, uris: List<Uri>): List<SendItem> = uris.mapNotNull { u ->
        try { ctx.contentResolver.takePersistableUriPermission(u, Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch (_: Exception) { }
        var name: String? = null
        var size = -1L
        try {
            ctx.contentResolver.query(u, null, null, null, null)?.use { c ->
                if (c.moveToFirst()) {
                    val n = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                    val s = c.getColumnIndex(OpenableColumns.SIZE)
                    if (n >= 0) name = c.getString(n)
                    if (s >= 0 && !c.isNull(s)) size = c.getLong(s)
                }
            }
        } catch (_: Exception) { }
        val nm = name ?: u.lastPathSegment?.substringAfterLast('/') ?: "file"
        if (size < 0) return@mapNotNull null
        val mime = ctx.contentResolver.getType(u) ?: guessMime(nm)
        SendItem(u, nm, size, mime, nm, categoryOf(nm, mime))
    }

    /** Walks a folder picked with the document tree picker and keeps the folder structure. */
    fun fromTree(ctx: Context, tree: Uri): List<SendItem> {
        try { ctx.contentResolver.takePersistableUriPermission(tree, Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch (_: Exception) { }
        val root = DocumentFile.fromTreeUri(ctx, tree) ?: return emptyList()
        val out = ArrayList<SendItem>()
        fun walk(d: DocumentFile, prefix: String, depth: Int) {
            if (depth > 10 || out.size >= 5000) return
            for (c in d.listFiles()) {
                val nm = c.name ?: continue
                if (c.isDirectory) walk(c, "$prefix$nm/", depth + 1)
                else if (out.size < 5000) {
                    val mime = c.type ?: guessMime(nm)
                    out.add(SendItem(c.uri, nm, c.length(), mime, "$prefix$nm", categoryOf(nm, mime), c.lastModified()))
                }
            }
        }
        walk(root, (root.name ?: "folder") + "/", 0)
        return out
    }
}
