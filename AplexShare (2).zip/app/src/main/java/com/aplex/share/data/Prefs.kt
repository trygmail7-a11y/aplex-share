package com.aplex.share.data

import android.content.Context
import android.content.SharedPreferences
import android.os.Build
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue

object Prefs {
    private lateinit var sp: SharedPreferences

    var deviceName by mutableStateOf("")
    var avatar by mutableIntStateOf(0)
    /** false = visible to everyone nearby, true = hidden (you can still send and use QR). */
    var visibilityHidden by mutableStateOf(false)
    var nearbyEnabled by mutableStateOf(true)
    /** 0 = system, 1 = light, 2 = dark */
    var theme by mutableIntStateOf(0)

    fun defaultName(): String = (Build.MODEL ?: "Android").take(24)

    fun init(ctx: Context) {
        sp = ctx.getSharedPreferences("aplex_prefs", Context.MODE_PRIVATE)
        deviceName = sp.getString("name", null) ?: defaultName()
        avatar = sp.getInt("avatar", 0)
        visibilityHidden = sp.getBoolean("hidden", false)
        nearbyEnabled = sp.getBoolean("nearby", true)
        theme = sp.getInt("theme", 0)
    }

    fun save() {
        sp.edit()
            .putString("name", deviceName)
            .putInt("avatar", avatar)
            .putBoolean("hidden", visibilityHidden)
            .putBoolean("nearby", nearbyEnabled)
            .putInt("theme", theme)
            .apply()
    }
}
